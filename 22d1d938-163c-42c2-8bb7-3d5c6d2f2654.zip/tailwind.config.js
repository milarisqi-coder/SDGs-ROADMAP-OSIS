export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#EEF2F7',
          100: '#D8E1EC',
          200: '#B3C3D8',
          DEFAULT: '#1E3A5F',
          700: '#172E4C',
          800: '#122540',
          900: '#0E1C31',
        },
        sage: {
          50: '#F1F5F0',
          100: '#E1EADF',
          200: '#C6D6C3',
          DEFAULT: '#8FAE8B',
          600: '#6E8F6A',
          700: '#4F6B49',
        },
        beige: {
          50: '#FAF6EF',
          100: '#F4EDE1',
          DEFAULT: '#E9DCC6',
          300: '#DCC9AA',
          700: '#7A6446',
        },
        muted: {
          50: '#EFF3F8',
          100: '#E0E8F1',
          DEFAULT: '#7C9CBF',
          700: '#46668B',
        },
        sunny: {
          50: '#FDF8E8',
          100: '#FBF0CF',
          DEFAULT: '#F2D57E',
          700: '#735A0E',
        },
        danger: {
          50: '#FBECEC',
          DEFAULT: '#B42318',
        },
        cream: '#F7F5EF',
        ink: {
          DEFAULT: '#1B2733',
          soft: '#4A5866',
          faint: '#646F7D',
        },
        line: '#E7E2D7',
      },
      fontFamily: {
        heading: ['Poppins', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 1px 2px rgba(30,58,95,0.04), 0 8px 24px -14px rgba(30,58,95,0.14)',
        lift: '0 2px 4px rgba(30,58,95,0.05), 0 22px 44px -20px rgba(30,58,95,0.28)',
      },
      transitionTimingFunction: {
        out: 'cubic-bezier(0.23, 1, 0.32, 1)',
      },
    },
  },
  plugins: [],
};
