import { format } from 'date-fns';
import { id } from 'date-fns/locale';

export function isPlaceholder(value: string): boolean {
  return value.trim().startsWith('[');
}

export function placeholderClass(value: string): string {
  return isPlaceholder(value) ? 'text-ink-faint italic' : '';
}

export function formatDateTime(date: Date): string {
  return format(date, 'd MMM yyyy, HH:mm', { locale: id });
}

export function makeId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function initials(name: string): string {
  if (isPlaceholder(name)) return '';
  return name.
  split(' ').
  filter(Boolean).
  slice(0, 2).
  map((part) => part[0]?.toUpperCase() ?? '').
  join('');
}