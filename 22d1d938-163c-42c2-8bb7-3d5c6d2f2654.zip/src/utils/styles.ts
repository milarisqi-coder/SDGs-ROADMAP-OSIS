export const container = 'mx-auto w-full max-w-7xl px-5 sm:px-8';

const focusRing =
'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy focus-visible:ring-offset-2 focus-visible:ring-offset-cream';

export const btnPrimary = `inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full bg-navy px-6 py-3 text-[15px] font-semibold text-white shadow-soft transition-[background-color,transform] duration-150 ease-out hover:bg-navy-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 ${focusRing}`;

export const btnSecondary = `inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full border border-navy/15 bg-white px-6 py-3 text-[15px] font-semibold text-navy transition-[background-color,border-color,transform] duration-150 ease-out hover:border-navy/30 hover:bg-navy-50 active:scale-[0.98] ${focusRing}`;

export const btnSmall = `inline-flex items-center justify-center gap-1.5 whitespace-nowrap rounded-full px-3.5 py-2 text-sm font-semibold transition-[background-color,color,transform] duration-150 ease-out active:scale-[0.97] ${focusRing}`;

export const iconBtn = `inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-ink-soft transition-[background-color,color] duration-150 ease-out hover:bg-navy-50 hover:text-navy disabled:pointer-events-none disabled:opacity-30 ${focusRing}`;

export const inputClass =
'w-full rounded-xl border border-line bg-white px-3.5 py-2.5 text-[15px] text-ink placeholder:text-ink-faint transition-[border-color,box-shadow] duration-150 focus:border-navy focus:outline-none focus:ring-2 focus:ring-navy/15 disabled:bg-cream disabled:text-ink-faint';