import type { Program } from '../types/program';
import { makeId } from './text';

export function createBlankProgram(year: string, index: number): Program {
  return {
    id: makeId('prog'),
    name: `[Program OSIS ${index.toString().padStart(2, '0')}]`,
    division: '',
    year,
    sdgs: [],
    status: 'Berjalan',
    summary: '',
    background: '',
    goal: '',
    pic: '',
    target: '',
    indicators: [],
    period: '',
    progress: 0,
    documentation: [],
    evaluation: '',
    obstacles: '',
    solutions: '',
    lessons: '',
    development: ''
  };
}