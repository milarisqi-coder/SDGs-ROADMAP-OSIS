import { sdgs } from '../data/sdgs';
import type { Sdg } from '../types/content';

export function getSdg(number: number): Sdg {
  const found = sdgs.find((s) => s.number === number);
  if (!found) throw new Error(`SDG ${number} not found`);
  return found;
}

export function padNumber(value: number): string {
  return value.toString().padStart(2, '0');
}

export const PRIORITY_NUMBERS = [1, 3, 4, 8, 15, 17];