import React from 'react';
import { QuoteIcon } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { FlowSteps } from '../components/ui/FlowSteps';
import { Reveal } from '../components/ui/Reveal';
import { NextStep } from '../components/ui/NextStep';
import { siteImages } from '../data/images';
import { problemCards, solutionFlow } from '../data/storyContent';
import { container } from '../utils/styles';

export function WhyPage() {
  return (
    <div>
      <PageHeader title="Mengapa Website Ini Ada?" />

      <section className={`${container} grid items-center gap-10 pb-16 lg:grid-cols-[1.1fr_1fr]`}>
        <div>
          <p className="font-heading text-2xl font-medium leading-snug text-navy sm:text-3xl">
            Kegiatan OSIS sudah banyak. Tetapi, sudahkah setiap proses dan pembelajarannya terdokumentasi?
          </p>
          <p className="mt-6 text-lg leading-relaxed text-ink-soft">
            Setiap tahun, OSIS menjalankan banyak kegiatan yang bermanfaat. Namun ketika kepengurusan berganti, cerita di balik
            kegiatan itu — alasan, cara menjalankan, kendala, dan pelajarannya — sering tidak ikut tersimpan.
          </p>
        </div>
        <div className="overflow-hidden rounded-[28px] border border-line bg-white shadow-soft">
          <img
            src={siteImages.why}
            alt="Ilustrasi kakak kelas menyerahkan catatan dokumentasi kepada adik kelas"
            className="aspect-[4/3] w-full object-cover" />
          
        </div>
      </section>

      <section className={`${container} pb-20`} aria-labelledby="problem-title">
        <h2 id="problem-title" className="font-heading text-2xl font-semibold text-navy">
          Tiga masalah yang sering terjadi
        </h2>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {problemCards.map((card, i) => {
            const Icon = card.icon;
            return (
              <Reveal key={card.number} delay={i * 0.05} className="h-full">
                <article className="flex h-full flex-col rounded-3xl border border-line bg-white p-7 shadow-soft">
                  <div className="flex items-center justify-between">
                    <span className="font-heading text-4xl font-semibold text-navy-100">{card.number}</span>
                    <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-beige-100 text-beige-700">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                  </div>
                  <h3 className="mt-6 font-heading text-lg font-semibold uppercase tracking-wide text-navy">{card.title}</h3>
                  <p className="mt-3 leading-relaxed text-ink-soft">{card.body}</p>
                </article>
              </Reveal>);

          })}
        </div>
      </section>

      <section className="bg-sage-50 py-20" aria-labelledby="solution-title">
        <div className={container}>
          <Reveal className="grid gap-8 lg:grid-cols-[1fr_1.2fr] lg:gap-16">
            <h2 id="solution-title" className="font-heading text-3xl font-semibold leading-tight text-navy sm:text-4xl">
              Maka, hadir SDGs Roadmap OSIS.
            </h2>
            <p className="text-lg leading-relaxed text-ink-soft">
              Website ini menjadi ruang untuk mengenalkan SDGs, memetakan program OSIS, mendokumentasikan kegiatan, dan membantu
              proses regenerasi agar pengalaman satu kepengurusan dapat menjadi bekal bagi kepengurusan berikutnya.
            </p>
          </Reveal>
          <Reveal className="mt-12">
            <FlowSteps steps={solutionFlow} />
          </Reveal>
        </div>
      </section>

      <section className={`${container} py-20`}>
        <Reveal>
          <blockquote className="relative rounded-[32px] bg-sunny-100 px-6 py-12 text-center sm:px-16 sm:py-16">
            <QuoteIcon className="mx-auto h-8 w-8 text-sunny-700" aria-hidden="true" />
            <p className="mx-auto mt-5 max-w-3xl font-heading text-2xl font-semibold leading-snug text-navy sm:text-[2rem]">
              Bukan memulai semuanya dari nol, tetapi melanjutkan apa yang sudah ada menjadi lebih baik.
            </p>
          </blockquote>
        </Reveal>
      </section>

      <NextStep to="sdgs" label="Mengenal 17 SDGs" description="Mulai dari dasar: tujuan global yang menjadi kerangka program OSIS." />
    </div>);

}