import React, { useState } from 'react';
import { RefreshCwIcon } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { NextStep } from '../components/ui/NextStep';
import { Reveal } from '../components/ui/Reveal';
import { RoadmapTrack } from '../components/roadmap/RoadmapTrack';
import { RoadmapStageDetail } from '../components/roadmap/RoadmapStageDetail';
import { roadmapStages } from '../data/roadmapStages';
import { container } from '../utils/styles';

export function RoadmapPage() {
  const [active, setActive] = useState(0);
  const [checks, setChecks] = useState<Record<string, boolean[]>>({});

  const stage = roadmapStages[active];

  const toggleCheck = (i: number) => {
    setChecks((prev) => {
      const current = prev[stage.code] ?? stage.checklist.map(() => false);
      const next = [...current];
      next[i] = !next[i];
      return { ...prev, [stage.code]: next };
    });
  };

  const step = (direction: -1 | 1) => {
    setActive((v) => Math.min(roadmapStages.length - 1, Math.max(0, v + direction)));
  };

  return (
    <div>
      <PageHeader
        title="SDGs Roadmap OSIS"
        subtitle="Delapan tahapan untuk mengenal, menjalankan, mengevaluasi, dan melanjutkan program OSIS." />
      

      <section className={`${container} pb-8`} aria-label="Tahapan roadmap">
        <p className="mb-6 font-heading text-sm font-semibold tracking-[0.1em] text-ink-faint">
          KNOW → UNDERSTAND → MAP → PLAN → ACT → MONITOR → EVALUATE → REGENERATE
        </p>
        <RoadmapTrack stages={roadmapStages} active={active} onSelect={setActive} />
        <p className="mt-3 text-sm text-ink-faint lg:hidden">Geser ke samping untuk melihat semua tahap.</p>
      </section>

      <section className={`${container} pb-16`} aria-live="polite">
        <RoadmapStageDetail
          stage={stage}
          index={active}
          total={roadmapStages.length}
          checks={checks[stage.code] ?? stage.checklist.map(() => false)}
          onToggleCheck={toggleCheck}
          onStep={step} />
        
      </section>

      <section className={`${container} pb-8`}>
        <Reveal>
          <div className="relative overflow-hidden rounded-[32px] bg-navy px-6 py-14 text-center sm:px-16 sm:py-20">
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-sunny text-navy-900">
              <RefreshCwIcon className="h-6 w-6" aria-hidden="true" />
            </span>
            <p className="mx-auto mt-6 max-w-3xl font-heading text-3xl font-semibold leading-tight text-white sm:text-[2.6rem]">
              Dari satu kepengurusan, menjadi pengetahuan untuk generasi berikutnya.
            </p>
          </div>
        </Reveal>
      </section>

      <NextStep to="handbook" label="Gunakan SDGs Handbook OSIS" description="Panduan digital jangka panjang untuk setiap generasi pengurus." />
    </div>);

}