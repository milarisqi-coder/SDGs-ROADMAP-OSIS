import React, { useMemo, useState } from 'react';
import { InfoIcon, PlusIcon, SearchXIcon } from 'lucide-react';
import { toast } from 'sonner';
import { PageHeader } from '../components/ui/PageHeader';
import { NextStep } from '../components/ui/NextStep';
import { ProgramCard } from '../components/program/ProgramCard';
import { ProgramDetailModal } from '../components/program/ProgramDetailModal';
import { ProgramFormModal } from '../components/program/ProgramFormModal';
import { useSchoolData } from '../contexts/SchoolDataContext';
import { useEditMode } from '../contexts/EditModeContext';
import type { Program } from '../types/program';
import { createBlankProgram } from '../utils/program';
import { btnPrimary, container } from '../utils/styles';

interface ProgramFilter {
  id: string;
  label: string;
  match: (p: Program) => boolean;
}

const filters: ProgramFilter[] = [
{ id: 'semua', label: 'Semua', match: () => true },
...[1, 3, 4, 8, 15, 17].map((n) => ({ id: `sdg-${n}`, label: `SDG ${n}`, match: (p: Program) => p.sdgs.includes(n) })),
{ id: 'berjalan', label: 'Berjalan', match: (p) => p.status === 'Berjalan' },
{ id: 'selesai', label: 'Selesai', match: (p) => p.status === 'Selesai' },
{ id: 'evaluasi', label: 'Perlu Evaluasi', match: (p) => p.status === 'Perlu Evaluasi' }];


export function ProgramsPage() {
  const { programs, saveProgram, deleteProgram, period } = useSchoolData();
  const { isEditing } = useEditMode();
  const [activeFilter, setActiveFilter] = useState('semua');
  const [detailId, setDetailId] = useState<string | null>(null);
  const [formState, setFormState] = useState<{program: Program;isNew: boolean;} | null>(null);

  const filter = filters.find((f) => f.id === activeFilter) ?? filters[0];
  const visible = useMemo(() => programs.filter(filter.match), [programs, filter]);
  const detailProgram = programs.find((p) => p.id === detailId) ?? null;

  const openEdit = (program: Program) => {
    setDetailId(null);
    setFormState({ program, isNew: false });
  };

  const handleSave = (program: Program) => {
    saveProgram(program);
    setFormState(null);
    toast.success('Program tersimpan.');
  };

  return (
    <div>
      <PageHeader title="Program Kerja OSIS" subtitle="Kenali program yang telah, sedang, dan akan dijalankan oleh OSIS.">
        {isEditing &&
        <button type="button" onClick={() => setFormState({ program: createBlankProgram(period, programs.length + 1), isNew: true })} className={btnPrimary}>
            <PlusIcon className="h-4 w-4" aria-hidden="true" />
            Tambah Program
          </button>
        }
      </PageHeader>

      <div className={`${container} pb-6`}>
        <p className="flex items-start gap-2 rounded-2xl bg-beige-50 px-5 py-4 text-sm text-ink-soft">
          <InfoIcon className="mt-0.5 h-4 w-4 shrink-0 text-beige-700" aria-hidden="true" />
          Program di bawah adalah template contoh. Ganti nama dan isinya dengan program OSIS yang sebenarnya melalui Edit Mode.
        </p>
      </div>

      <div className={`${container} py-3`}>
        <div role="toolbar" aria-label="Filter program" className="scrollbar-none -mx-5 flex gap-2 overflow-x-auto px-5 sm:mx-0 sm:flex-wrap sm:px-0">
          {filters.map((f) => {
            const active = f.id === activeFilter;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setActiveFilter(f.id)}
                aria-pressed={active}
                className={`shrink-0 whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold transition-[background-color,color,border-color] duration-150 ${
                active ? 'bg-navy text-white' : 'border border-line bg-white text-ink-soft hover:border-navy/30 hover:text-navy'}`
                }>
                
                {f.label}
              </button>);

          })}
        </div>
      </div>

      <section className={`${container} pb-12 pt-6`} aria-live="polite">
        <p className="mb-5 text-sm text-ink-faint">
          Menampilkan {visible.length} dari {programs.length} program
        </p>
        {visible.length > 0 ?
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {visible.map((program) =>
          <ProgramCard
            key={program.id}
            program={program}
            editing={isEditing}
            onOpen={() => setDetailId(program.id)}
            onEdit={() => openEdit(program)}
            onDelete={() => {
              deleteProgram(program.id);
              toast.success('Program dihapus.');
            }} />

          )}
          </div> :

        <div className="flex flex-col items-center rounded-3xl border border-dashed border-line bg-white px-6 py-16 text-center">
            <SearchXIcon className="h-8 w-8 text-ink-faint" aria-hidden="true" />
            <p className="mt-4 font-heading text-lg font-semibold text-navy">Belum ada program untuk filter ini</p>
            <p className="mt-1 text-ink-soft">Coba filter lain, atau tambahkan program melalui Edit Mode.</p>
            <button type="button" onClick={() => setActiveFilter('semua')} className="mt-5 text-sm font-semibold text-navy hover:text-sage-700">
              Tampilkan semua program
            </button>
          </div>
        }
      </section>

      <ProgramDetailModal program={detailProgram} onClose={() => setDetailId(null)} onEdit={openEdit} />
      <ProgramFormModal program={formState?.program ?? null} isNew={formState?.isNew ?? false} onSave={handleSave} onClose={() => setFormState(null)} />

      <NextStep to="roadmap" label="Ikuti 8 Tahap Roadmap OSIS" description="Panduan langkah demi langkah dari mengenal SDGs hingga mewariskan pengetahuan." />
    </div>);

}