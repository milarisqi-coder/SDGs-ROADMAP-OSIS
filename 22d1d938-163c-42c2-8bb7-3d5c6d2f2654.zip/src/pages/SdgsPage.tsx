import React, { useState } from 'react';
import { StarIcon } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { NextStep } from '../components/ui/NextStep';
import { SdgCard } from '../components/sdg/SdgCard';
import { SdgDetailModal } from '../components/sdg/SdgDetailModal';
import { sdgs } from '../data/sdgs';
import type { Sdg } from '../types/content';
import { container } from '../utils/styles';

export function SdgsPage() {
  const [selected, setSelected] = useState<Sdg | null>(null);

  const step = (direction: -1 | 1) => {
    if (!selected) return;
    const next = sdgs.find((s) => s.number === selected.number + direction);
    if (next) setSelected(next);
  };

  return (
    <div>
      <PageHeader
        title="Mengenal 17 Sustainable Development Goals"
        subtitle="SDGs atau Sustainable Development Goals merupakan 17 tujuan pembangunan berkelanjutan yang menjadi agenda global untuk menciptakan kehidupan yang lebih baik dan berkelanjutan.">
        
        <p className="flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm text-ink-soft ring-1 ring-line">
          <StarIcon className="h-4 w-4 text-sunny-700" aria-hidden="true" />6 tujuan ditandai sebagai Prioritas OSIS
        </p>
      </PageHeader>

      <section className={`${container} pb-12`} aria-label="Daftar 17 SDGs">
        <p className="mb-4 text-sm text-ink-faint md:hidden">Ketuk panah untuk membaca penjelasan singkat, atau ketuk gambar untuk detail.</p>
        <div className="grid gap-4 md:grid-cols-3 md:gap-6 xl:grid-cols-4">
          {sdgs.map((sdg) =>
          <SdgCard key={sdg.number} sdg={sdg} onOpen={setSelected} />
          )}
        </div>
      </section>

      <SdgDetailModal sdg={selected} onClose={() => setSelected(null)} onStep={step} />

      <NextStep to="prioritas" label="Fokus pada 6 Prioritas SDGs" description="Enam tujuan yang paling dekat dengan kehidupan siswa dan program OSIS." />
    </div>);

}