import React, { useState } from 'react';
import { BookOpenIcon, DownloadIcon, UsersIcon } from 'lucide-react';
import { toast } from 'sonner';
import { PageHeader } from '../components/ui/PageHeader';
import { Reveal } from '../components/ui/Reveal';
import { HandbookBook } from '../components/handbook/HandbookBook';
import { HandbookToc } from '../components/handbook/HandbookToc';
import { HandbookReaderModal } from '../components/handbook/HandbookReaderModal';
import { HandbookResources } from '../components/handbook/HandbookResources';
import { useSchoolData } from '../contexts/SchoolDataContext';
import { useEditMode } from '../contexts/EditModeContext';
import { useNavigation } from '../contexts/NavigationContext';
import { btnPrimary, btnSecondary, container } from '../utils/styles';

export function HandbookPage() {
  const { chapters, period } = useSchoolData();
  const { isEditing } = useEditMode();
  const { goTo } = useNavigation();
  const [readerId, setReaderId] = useState<string | null>(null);

  const handleDownload = () => {
    toast('File PDF handbook belum diunggah.', {
      description: 'Pengurus berwenang dapat menambahkan file handbook melalui Edit Mode.'
    });
  };

  return (
    <div>
      <PageHeader
        title="SDGs Handbook OSIS"
        subtitle="Panduan digital untuk membantu pengurus OSIS memahami SDGs dan menghubungkannya dengan program kerja." />
      

      <section className={`${container} grid gap-12 pb-16 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16`}>
        <div className="lg:sticky lg:top-36 lg:self-start">
          <HandbookBook period={period} />
          <div className="mx-auto mt-10 flex max-w-[360px] flex-col gap-3">
            <button type="button" onClick={() => setReaderId(chapters[0]?.id ?? null)} className={btnPrimary}>
              <BookOpenIcon className="h-4 w-4" aria-hidden="true" />
              Buka Handbook
            </button>
            <button type="button" onClick={handleDownload} className={btnSecondary}>
              <DownloadIcon className="h-4 w-4" aria-hidden="true" />
              Download Handbook
            </button>
          </div>
        </div>

        <div className="space-y-12">
          <div>
            <div className="flex items-end justify-between gap-4">
              <h2 className="font-heading text-2xl font-semibold text-navy">Daftar Isi</h2>
              <span className="text-sm text-ink-faint">{chapters.length} bab</span>
            </div>
            <div className="mt-5">
              <HandbookToc editing={isEditing} onOpenChapter={setReaderId} />
            </div>
          </div>

          <Reveal>
            <aside className="flex gap-5 rounded-3xl bg-sage-100 p-6 sm:p-8">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-sage-700">
                <UsersIcon className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <h2 className="font-heading text-xl font-semibold text-navy">Untuk Generasi Berikutnya</h2>
                <p className="mt-2 leading-relaxed text-ink-soft">
                  Handbook ini dapat digunakan kembali dan dikembangkan oleh pengurus OSIS berikutnya sebagai panduan dalam
                  menjalankan program dan meneruskan pembelajaran dari periode sebelumnya.
                </p>
              </div>
            </aside>
          </Reveal>

          <HandbookResources editing={isEditing} />
        </div>
      </section>

      <section className={`${container} pb-20`} aria-labelledby="regen-title">
        <div className="rounded-[32px] bg-navy px-6 py-12 text-white sm:px-12 sm:py-16">
          <p className="font-heading text-sm font-bold tracking-[0.14em] text-sunny">REGENERASI PENGETAHUAN</p>
          <h2 id="regen-title" className="mt-3 max-w-3xl font-heading text-3xl font-semibold leading-tight sm:text-4xl">
            Di akhir periode, wariskan apa yang sudah dipelajari.
          </h2>
          <p className="mt-4 max-w-2xl text-lg leading-relaxed text-navy-100">
            Perbarui struktur OSIS, lengkapi lessons learned di setiap program, lalu serahkan handbook ini kepada pengurus berikutnya.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <button
              type="button"
              onClick={() => goTo('struktur')}
              className="inline-flex items-center justify-center whitespace-nowrap rounded-full bg-sunny px-6 py-3 text-[15px] font-semibold text-navy-900 transition-[background-color,transform] duration-150 ease-out hover:bg-sunny-100 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sunny focus-visible:ring-offset-2 focus-visible:ring-offset-navy">
              
              Perbarui Struktur OSIS
            </button>
            <button
              type="button"
              onClick={() => goTo('program')}
              className="inline-flex items-center justify-center whitespace-nowrap rounded-full border border-white/25 px-6 py-3 text-[15px] font-semibold text-white transition-[background-color,border-color,transform] duration-150 ease-out hover:border-white/50 hover:bg-white/10 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sunny">
              
              Lengkapi Lessons Learned
            </button>
          </div>
        </div>
      </section>

      <HandbookReaderModal chapterId={readerId} onChange={setReaderId} onClose={() => setReaderId(null)} />
    </div>);

}