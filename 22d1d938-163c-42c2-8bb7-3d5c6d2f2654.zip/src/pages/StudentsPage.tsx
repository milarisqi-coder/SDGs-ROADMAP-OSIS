import React from 'react';
import { QuoteIcon } from 'lucide-react';
import { PageHeader } from '../components/ui/PageHeader';
import { FlowSteps } from '../components/ui/FlowSteps';
import { Reveal } from '../components/ui/Reveal';
import { NextStep } from '../components/ui/NextStep';
import { siteImages } from '../data/images';
import { studentFlow, studentReasons } from '../data/storyContent';
import { container } from '../utils/styles';

export function StudentsPage() {
  return (
    <div>
      <PageHeader title="Kenapa Pelajar Perlu Mengetahui SDGs?" />

      <section className={`${container} grid items-center gap-10 pb-16 lg:grid-cols-[1.1fr_1fr]`}>
        <p className="font-heading text-2xl font-medium leading-snug text-navy sm:text-3xl">
          SDGs bukan hanya milik pemerintah atau organisasi besar. Pelajar juga dapat mengenali masalah di sekitarnya dan
          mengambil bagian melalui tindakan sederhana.
        </p>
        <div className="overflow-hidden rounded-[28px] border border-line bg-white shadow-soft">
          <img
            src={siteImages.students}
            alt="Ilustrasi siswa SMP berdiskusi dan bertukar ide di sekitar meja"
            className="aspect-[4/3] w-full object-cover" />
          
        </div>
      </section>

      <section className={`${container} pb-20`} aria-label="Lima alasan">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-6">
          {studentReasons.map((card, i) => {
            const Icon = card.icon;
            const wide = i < 2;
            return (
              <Reveal key={card.number} delay={i * 0.04} className={`h-full ${wide ? 'lg:col-span-3' : 'lg:col-span-2'} ${i === 4 ? 'md:col-span-2 lg:col-span-2' : ''}`}>
                <article
                  className={`flex h-full flex-col rounded-3xl p-7 transition-[transform,box-shadow] duration-200 ease-out hover:-translate-y-1 ${
                  wide ? 'bg-navy text-white shadow-lift' : 'border border-line bg-white shadow-soft hover:shadow-lift'}`
                  }>
                  
                  <div className="flex items-center justify-between">
                    <span className={`flex h-12 w-12 items-center justify-center rounded-2xl ${wide ? 'bg-sunny text-navy-900' : 'bg-sage-100 text-sage-700'}`}>
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <span className={`font-heading text-3xl font-semibold ${wide ? 'text-white/25' : 'text-navy-100'}`}>{card.number}</span>
                  </div>
                  <h2 className={`mt-6 font-heading font-semibold uppercase tracking-wide ${wide ? 'text-xl text-white' : 'text-lg text-navy'}`}>
                    {card.title}
                  </h2>
                  <p className={`mt-3 leading-relaxed ${wide ? 'text-lg text-navy-100' : 'text-ink-soft'}`}>{card.body}</p>
                </article>
              </Reveal>);

          })}
        </div>
      </section>

      <section className="border-y border-line bg-white py-20" aria-labelledby="process-title">
        <div className={container}>
          <h2 id="process-title" className="font-heading text-3xl font-semibold text-navy">
            Dari tahu, menjadi dampak
          </h2>
          <p className="mt-3 max-w-2xl text-lg text-ink-soft">Lima langkah sederhana yang dapat dilakukan setiap siswa.</p>
          <Reveal className="mt-10">
            <FlowSteps steps={studentFlow} />
          </Reveal>
        </div>
      </section>

      <section className={`${container} py-20`}>
        <Reveal>
          <blockquote className="rounded-[32px] bg-sage-100 px-6 py-12 text-center sm:px-16 sm:py-16">
            <QuoteIcon className="mx-auto h-8 w-8 text-sage-700" aria-hidden="true" />
            <p className="mx-auto mt-5 max-w-3xl font-heading text-2xl font-semibold leading-snug text-navy sm:text-[2rem]">
              Perubahan tidak selalu dimulai dari sesuatu yang besar. Bisa dimulai dari siswa yang peduli terhadap masalah di
              sekitarnya.
            </p>
          </blockquote>
        </Reveal>
      </section>

      <NextStep to="struktur" label="Siapa yang Menggerakkan Program OSIS?" description="Kenali struktur pengurus yang bertanggung jawab atas setiap program." />
    </div>);

}