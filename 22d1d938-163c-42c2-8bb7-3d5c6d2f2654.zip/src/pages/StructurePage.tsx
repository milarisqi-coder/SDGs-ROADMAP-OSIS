import React, { useState } from 'react';
import { HistoryIcon, LockIcon, PencilIcon } from 'lucide-react';
import { toast } from 'sonner';
import { PageHeader } from '../components/ui/PageHeader';
import { NextStep } from '../components/ui/NextStep';
import { OrgChart } from '../components/structure/OrgChart';
import { MemberFormModal } from '../components/structure/MemberFormModal';
import { DivisionFormModal } from '../components/structure/DivisionFormModal';
import { useSchoolData } from '../contexts/SchoolDataContext';
import { useEditMode } from '../contexts/EditModeContext';
import type { Division, Member } from '../types/organization';
import { btnSmall, container, inputClass } from '../utils/styles';
import { makeId } from '../utils/text';

export function StructurePage() {
  const { organization, period, setPeriod, saveMember, saveDivision } = useSchoolData();
  const { isEditing, requestEditMode } = useEditMode();

  const [editingMember, setEditingMember] = useState<{member: Member;isNew: boolean;} | null>(null);
  const [divisionModal, setDivisionModal] = useState<{division: Division | null;} | null>(null);
  const [periodDraft, setPeriodDraft] = useState<string | null>(null);

  const handleAddMember = (divisionId: string) => {
    setEditingMember({
      member: { id: makeId('m'), name: '', position: 'Anggota', divisionId, period, photo: '' },
      isNew: true
    });
  };

  const handleSaveMember = (member: Member) => {
    saveMember(member);
    setEditingMember(null);
    toast.success('Data pengurus tersimpan.');
  };

  const handleSaveDivision = (name: string) => {
    const existing = divisionModal?.division;
    saveDivision({ id: existing?.id ?? makeId('div'), name });
    setDivisionModal(null);
    toast.success(existing ? 'Seksi bidang diperbarui.' : 'Seksi bidang ditambahkan.');
  };

  const savePeriod = () => {
    if (periodDraft && periodDraft.trim()) {
      setPeriod(periodDraft.trim());
      toast.success('Periode kepengurusan diperbarui.');
    }
    setPeriodDraft(null);
  };

  return (
    <div>
      <PageHeader
        title="Siapa yang Menggerakkan Program OSIS?"
        subtitle="Struktur ini adalah template yang dapat diperbarui setiap periode. Nama pengurus diisi oleh pengurus berwenang melalui Edit Mode.">
        
        <div className="rounded-2xl border border-line bg-white p-5 shadow-soft">
          <p className="text-sm font-medium text-ink-faint">Current Period</p>
          {periodDraft !== null ?
          <div className="mt-2 flex items-center gap-2">
              <label htmlFor="period-input" className="sr-only">
                Periode kepengurusan
              </label>
              <input id="period-input" className={`${inputClass} w-32`} value={periodDraft} onChange={(e) => setPeriodDraft(e.target.value)} autoFocus />
              <button type="button" onClick={savePeriod} className={`${btnSmall} bg-navy text-white hover:bg-navy-700`}>
                Save
              </button>
              <button type="button" onClick={() => setPeriodDraft(null)} className={`${btnSmall} text-ink-soft hover:bg-cream`}>
                Cancel
              </button>
            </div> :

          <div className="mt-1 flex items-center gap-3">
              <p className="font-heading text-3xl font-semibold text-navy">{period}</p>
              {isEditing &&
            <button type="button" onClick={() => setPeriodDraft(period)} className={`${btnSmall} bg-navy-50 text-navy hover:bg-navy-100`}>
                  <PencilIcon className="h-3.5 w-3.5" aria-hidden="true" />
                  Edit
                </button>
            }
            </div>
          }
        </div>
      </PageHeader>

      {!isEditing &&
      <div className={`${container} pb-8`}>
          <div className="flex flex-col gap-3 rounded-2xl bg-beige-50 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
            <p className="flex items-center gap-2 text-sm text-ink-soft">
              <LockIcon className="h-4 w-4 shrink-0 text-beige-700" aria-hidden="true" />
              Mode lihat. Pengurus berwenang dapat mengisi nama, jabatan, dan seksi melalui Edit Mode.
            </p>
            <button type="button" onClick={requestEditMode} className={`${btnSmall} bg-white text-navy ring-1 ring-line hover:bg-navy-50`}>
              <PencilIcon className="h-3.5 w-3.5" aria-hidden="true" />
              Masuk Edit Mode
            </button>
          </div>
        </div>
      }

      <section className={`${container} pb-16`} aria-label="Bagan organisasi OSIS">
        <div className="rounded-[32px] border border-line bg-cream px-4 py-10 sm:px-8 lg:px-12">
          <OrgChart
            editing={isEditing}
            onEditMember={(m) => setEditingMember({ member: m, isNew: false })}
            onAddMember={handleAddMember}
            onEditDivision={(d) => setDivisionModal({ division: d })} />
          
        </div>
      </section>

      <section className={`${container} pb-8`}>
        <div className="grid gap-6 rounded-[28px] bg-navy p-7 text-white sm:p-10 lg:grid-cols-[auto_1fr] lg:items-center lg:gap-10">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-sunny text-navy-900">
            <HistoryIcon className="h-6 w-6" aria-hidden="true" />
          </span>
          <div>
            <h2 className="font-heading text-2xl font-semibold">Untuk Regenerasi</h2>
            <p className="mt-2 max-w-3xl text-lg leading-relaxed text-navy-100">
              Struktur OSIS dapat diperbarui setiap periode kepengurusan sehingga informasi pengurus tetap relevan dan dapat menjadi
              dokumentasi bagi generasi berikutnya.
            </p>
          </div>
        </div>
      </section>

      <MemberFormModal
        member={editingMember?.member ?? null}
        isNew={editingMember?.isNew ?? false}
        divisions={organization.divisions}
        onSave={handleSaveMember}
        onClose={() => setEditingMember(null)} />
      
      <DivisionFormModal
        open={divisionModal !== null}
        initialName={divisionModal?.division?.name ?? ''}
        isNew={!divisionModal?.division}
        onSave={handleSaveDivision}
        onClose={() => setDivisionModal(null)} />
      

      <NextStep to="program" label="Jelajahi Program Kerja OSIS" description="Lihat program yang telah, sedang, dan akan dijalankan oleh setiap seksi." />
    </div>);

}