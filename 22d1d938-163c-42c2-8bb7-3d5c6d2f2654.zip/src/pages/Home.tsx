import React from 'react';
import { ArrowRightIcon, ArrowUpRightIcon } from 'lucide-react';
import { HeroVisual } from '../components/home/HeroVisual';
import { FlowSteps } from '../components/ui/FlowSteps';
import { Reveal } from '../components/ui/Reveal';
import { NextStep } from '../components/ui/NextStep';
import { useNavigation } from '../contexts/NavigationContext';
import { conceptLines, homeFlow } from '../data/storyContent';
import { btnPrimary, btnSecondary, container } from '../utils/styles';

export function Home() {
  const { goTo } = useNavigation();

  return (
    <div>
      <section className={`${container} grid items-center gap-12 pb-16 pt-10 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:pb-24 lg:pt-16`}>
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-sunny bg-sunny-100 px-3.5 py-1.5 text-xs font-bold tracking-[0.12em] text-navy">
            ONE STUDENT, ONCE IMPACT
          </span>
          <h1 className="mt-6 font-heading text-[2.4rem] font-semibold leading-[1.1] text-navy sm:text-5xl lg:text-[3.6rem]">
            Dari Program OSIS, Menjadi <span className="text-sage-700">Dampak yang Berkelanjutan.</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-soft">
            Mengenal, memetakan, dan mengembangkan program OSIS melalui SDGs untuk menciptakan perubahan yang dapat dilanjutkan
            dari satu generasi ke generasi berikutnya.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <button type="button" onClick={() => goTo('roadmap')} className={btnPrimary}>
              Jelajahi Roadmap OSIS
              <ArrowRightIcon className="h-4 w-4" aria-hidden="true" />
            </button>
            <button type="button" onClick={() => goTo('sdgs')} className={btnSecondary}>
              Kenali SDGs
            </button>
          </div>
          <p className="mt-8 text-sm text-ink-faint">Platform edukasi & dokumentasi OSIS · SMP Negeri 37 Surabaya</p>
        </div>
        <HeroVisual />
      </section>

      <section className="border-y border-line bg-white py-20" aria-labelledby="intro-title">
        <div className={container}>
          <Reveal className="grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
            <h2 id="intro-title" className="font-heading text-3xl font-semibold leading-tight text-navy sm:text-4xl">
              OSIS bukan hanya tentang menjalankan kegiatan.
            </h2>
            <p className="text-lg leading-relaxed text-ink-soft lg:pt-2">
              Setiap kegiatan yang dilakukan dapat menjadi bagian dari proses belajar, memberikan manfaat bagi warga sekolah, dan
              menciptakan dampak yang dapat dikembangkan oleh generasi berikutnya.
            </p>
          </Reveal>

          <Reveal className="mt-14 rounded-[32px] bg-navy p-6 sm:p-10">
            <div className="mb-8 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <p className="font-heading text-2xl font-semibold text-white">ALUR SDGs ROADMAP OSIS</p>
              <p className="text-navy-100">Dari kegiatan yang sudah ada, menjadi dampak yang terus berlanjut.</p>
            </div>
            <FlowSteps steps={homeFlow} tone="dark" />
          </Reveal>
        </div>
      </section>

      <section className={`${container} py-20`} aria-label="Konsep utama">
        <Reveal>
          <ul className="divide-y divide-line border-y border-line">
            {conceptLines.map((line) =>
            <li key={line.text}>
                <button
                type="button"
                onClick={() => goTo(line.tab)}
                className="group flex w-full items-center justify-between gap-4 py-6 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy">
                
                  <span className="font-heading text-2xl font-semibold text-navy transition-colors duration-150 group-hover:text-sage-700 sm:text-4xl">
                    {line.text}
                  </span>
                  <ArrowUpRightIcon
                  className="h-6 w-6 shrink-0 text-ink-faint transition-[transform,color] duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-sage-700"
                  aria-hidden="true" />
                
                </button>
              </li>
            )}
          </ul>
        </Reveal>
      </section>

      <NextStep to="mengapa" label="Mengapa Website Ini Ada?" description="Pahami masalah yang ingin diselesaikan oleh SDGs Roadmap OSIS." />
    </div>);

}