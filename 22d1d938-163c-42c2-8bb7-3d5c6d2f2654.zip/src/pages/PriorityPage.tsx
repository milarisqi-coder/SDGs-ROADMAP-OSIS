import React, { useState } from 'react';
import { PageHeader } from '../components/ui/PageHeader';
import { NextStep } from '../components/ui/NextStep';
import { Reveal } from '../components/ui/Reveal';
import { PriorityCard } from '../components/sdg/PriorityCard';
import { PriorityCluster } from '../components/sdg/PriorityCluster';
import { PriorityDetailModal } from '../components/sdg/PriorityDetailModal';
import { prioritySdgs } from '../data/prioritySdgs';
import type { PriorityDetail } from '../types/content';
import { getSdg } from '../utils/sdg';
import { container } from '../utils/styles';

export function PriorityPage() {
  const [selected, setSelected] = useState<PriorityDetail | null>(null);

  const openByNumber = (n: number) => {
    const found = prioritySdgs.find((p) => p.number === n);
    if (found) setSelected(found);
  };

  return (
    <div>
      <PageHeader
        title="6 Prioritas SDGs dalam Program OSIS"
        subtitle="Dari 17 tujuan SDGs, program ini memfokuskan pemetaan pada enam tujuan yang relevan dengan kehidupan siswa, lingkungan sekolah, dan pengembangan program OSIS." />
      

      <section className={`${container} pb-20`} aria-label="Enam prioritas SDGs">
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {prioritySdgs.map((detail, i) =>
          <Reveal key={detail.number} delay={i % 3 * 0.05} className="h-full">
              <PriorityCard sdg={getSdg(detail.number)} detail={detail} onOpen={() => setSelected(detail)} />
            </Reveal>
          )}
        </div>
      </section>

      <section className="border-y border-line bg-white py-20" aria-labelledby="cluster-title">
        <div className={container}>
          <div className="mx-auto max-w-2xl text-center">
            <h2 id="cluster-title" className="font-heading text-3xl font-semibold text-navy">
              Peta Prioritas SDGs
            </h2>
            <p className="mt-3 text-lg text-ink-soft">
              Setiap program OSIS berada di tengah dan dapat terhubung ke satu atau beberapa prioritas. Arahkan kursor atau ketuk
              sebuah SDG untuk melihat detailnya.
            </p>
          </div>
          <div className="mt-10">
            <PriorityCluster onSelect={openByNumber} />
          </div>
        </div>
      </section>

      <PriorityDetailModal detail={selected} onClose={() => setSelected(null)} />

      <div className="pt-14">
        <NextStep to="pelajar" label="Kenapa Pelajar Perlu Tahu SDGs?" description="Temukan peran siswa sebagai penggerak perubahan di sekolah." />
      </div>
    </div>);

}