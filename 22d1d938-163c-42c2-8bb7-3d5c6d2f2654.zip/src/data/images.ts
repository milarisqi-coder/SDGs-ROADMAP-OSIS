export const siteImages = {
  hero: "/00141929-48bd-47fd-b113-0e5c384d23e4.jpg",
  why: "/94e0beb1-54b1-466d-a0fd-f3a5084ad1ba.jpg",
  students: "/b94cbd81-c915-469d-b077-d5b496c21723.jpg"
};