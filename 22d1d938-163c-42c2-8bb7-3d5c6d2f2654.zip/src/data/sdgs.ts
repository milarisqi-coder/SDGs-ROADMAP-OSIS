import {
  HandHeartIcon,
  WheatIcon,
  HeartPulseIcon,
  BookOpenIcon,
  EqualIcon,
  DropletsIcon,
  SunIcon,
  TrendingUpIcon,
  FactoryIcon,
  UsersRoundIcon,
  Building2Icon,
  RecycleIcon,
  GlobeIcon,
  FishIcon,
  TreesIcon,
  LandmarkIcon,
  HandshakeIcon } from
'lucide-react';
import type { Sdg } from '../types/content';

export const sdgs: Sdg[] = [
{
  number: 1,
  name: 'Tanpa Kemiskinan',
  short: 'Berupaya mengakhiri kemiskinan dalam segala bentuk di mana pun.',
  color: '#E5243B',
  image: "/8d0f0de6-bfc7-4ce5-a5d0-56edff55d5c5.jpg",
  icon: HandHeartIcon,
  studentLink:
  'Pelajar bisa peka terhadap teman atau warga sekitar yang membutuhkan, dan belajar berbagi dengan cara yang tetap menghargai.',
  contributions: [
  'Berbagi buku atau seragam layak pakai',
  'Ikut kegiatan donasi yang terorganisasi',
  'Menghargai teman dari latar belakang apa pun'],

  osisExample: 'Kegiatan berbagi atau penggalangan donasi yang dikelola secara terbuka dan transparan.',
  priority: true
},
{
  number: 2,
  name: 'Tanpa Kelaparan',
  short: 'Mengakhiri kelaparan serta mendukung ketahanan pangan dan gizi yang baik.',
  color: '#DDA63A',
  darkText: true,
  image: "/c68ed7c1-9fe0-4dbe-8024-26fd047053ab.jpg",
  icon: WheatIcon,
  studentLink: 'Pelajar dapat belajar tentang gizi seimbang dan membiasakan diri tidak membuang-buang makanan.',
  contributions: [
  'Menghabiskan bekal dan tidak membuang makanan',
  'Menanam sayur sederhana di sekolah',
  'Memilih jajanan yang bergizi'],

  osisExample: 'Kampanye gizi seimbang atau gerakan membawa bekal sehat.'
},
{
  number: 3,
  name: 'Kehidupan Sehat dan Sejahtera',
  short: 'Mendorong kehidupan yang sehat dan kesejahteraan bagi semua.',
  color: '#4C9F38',
  image: "/2321336d-b281-4331-9ee9-efe47a4c9dfc.jpg",
  icon: HeartPulseIcon,
  studentLink: 'Kesehatan fisik dan mental memengaruhi semangat dan kemampuan belajar setiap siswa.',
  contributions: [
  'Berolahraga rutin dan cukup tidur',
  'Saling mendukung saat teman sedang kesulitan',
  'Menjaga kebersihan diri dan kelas'],

  osisExample: 'Olahraga bersama, senam pagi, atau ruang cerita untuk menjaga kesehatan mental.',
  priority: true
},
{
  number: 4,
  name: 'Pendidikan Berkualitas',
  short: 'Memastikan pendidikan yang inklusif, berkualitas, dan kesempatan belajar sepanjang hayat.',
  color: '#C5192D',
  image: "/ee857da7-d720-4118-b0d0-45bc2c820355.jpg",
  icon: BookOpenIcon,
  studentLink: 'Sekolah adalah tempat utama pelajar tumbuh. Setiap siswa berhak belajar dengan nyaman dan setara.',
  contributions: [
  'Belajar bersama teman sebaya',
  'Membaca buku di luar pelajaran',
  'Membantu teman yang tertinggal materi'],

  osisExample: 'Program literasi, pojok baca, atau kelompok belajar bersama.',
  priority: true
},
{
  number: 5,
  name: 'Kesetaraan Gender',
  short: 'Mencapai kesetaraan gender dan memberdayakan perempuan serta anak perempuan.',
  color: '#FF3A21',
  image: "/fb702db6-8dad-4202-83c6-a20939103ab2.jpg",
  icon: EqualIcon,
  studentLink: 'Siswa laki-laki dan perempuan punya kesempatan yang sama untuk memimpin, berpendapat, dan berprestasi.',
  contributions: [
  'Memberi kesempatan yang sama dalam kerja kelompok',
  'Tidak mengejek teman berdasarkan gender',
  'Mendukung teman yang ingin mencoba peran baru'],

  osisExample: 'Pembagian peran kepanitiaan yang adil dan terbuka untuk semua siswa.'
},
{
  number: 6,
  name: 'Air Bersih dan Sanitasi Layak',
  short: 'Menjamin ketersediaan serta pengelolaan air bersih dan sanitasi yang berkelanjutan.',
  color: '#26BDE2',
  darkText: true,
  image: "/ae6ca40f-fd4d-42a8-86d8-0038d6ae4db5.jpg",
  icon: DropletsIcon,
  studentLink: 'Air bersih dan toilet yang layak penting untuk kesehatan seluruh warga sekolah.',
  contributions: [
  'Mematikan keran setelah digunakan',
  'Menjaga kebersihan toilet sekolah',
  'Mencuci tangan dengan benar'],

  osisExample: 'Kampanye hemat air atau gerakan toilet bersih.'
},
{
  number: 7,
  name: 'Energi Bersih dan Terjangkau',
  short: 'Memastikan akses terhadap energi yang terjangkau, andal, berkelanjutan, dan modern.',
  color: '#FCC30B',
  darkText: true,
  image: "/8ce3bcc0-1a5b-422e-871e-dbd6687116eb.jpg",
  icon: SunIcon,
  studentLink: 'Listrik yang dipakai sehari-hari di sekolah dan rumah berkaitan langsung dengan energi yang kita gunakan.',
  contributions: [
  'Mematikan lampu dan kipas saat kelas kosong',
  'Mencabut charger yang tidak dipakai',
  'Belajar tentang energi terbarukan'],

  osisExample: 'Gerakan hemat energi di setiap kelas.'
},
{
  number: 8,
  name: 'Pekerjaan Layak dan Pertumbuhan Ekonomi',
  short: 'Mendorong pertumbuhan ekonomi yang inklusif serta pekerjaan yang layak.',
  color: '#A21942',
  image: "/c51a981b-6b35-4a25-9dd6-ef7024931aa3.jpg",
  icon: TrendingUpIcon,
  studentLink: 'Pelajar dapat mulai melatih keterampilan, kreativitas, dan kemandirian sejak dini.',
  contributions: [
  'Membuat produk kreatif sederhana',
  'Belajar mengelola uang saku',
  'Mengasah keterampilan seperti desain atau public speaking'],

  osisExample: 'Bazar kewirausahaan atau pelatihan keterampilan siswa.',
  priority: true
},
{
  number: 9,
  name: 'Industri, Inovasi dan Infrastruktur',
  short: 'Membangun infrastruktur yang tangguh dan mendorong inovasi serta industrialisasi berkelanjutan.',
  color: '#FD6925',
  darkText: true,
  image: "/978e7795-73d7-4113-b544-c6da46cc0980.jpg",
  icon: FactoryIcon,
  studentLink: 'Pelajar bisa berinovasi dan memanfaatkan teknologi untuk memecahkan masalah di sekitarnya.',
  contributions: [
  'Mengikuti kegiatan sains atau robotik',
  'Menggunakan teknologi secara bijak',
  'Membuat ide solusi untuk masalah di sekolah'],

  osisExample: 'Lomba inovasi atau pameran karya teknologi siswa.'
},
{
  number: 10,
  name: 'Berkurangnya Kesenjangan',
  short: 'Mengurangi kesenjangan di dalam dan antarnegara.',
  color: '#DD1367',
  image: "/cba99b50-528d-493a-8c3e-b2f9a664914e.jpg",
  icon: UsersRoundIcon,
  studentLink: 'Setiap siswa, apa pun latar belakangnya, berhak diperlakukan setara dan dilibatkan.',
  contributions: [
  'Mengajak teman yang jarang terlibat',
  'Menghargai perbedaan suku, agama, dan kemampuan',
  'Menolak perundungan'],

  osisExample: 'Kampanye anti-perundungan atau kegiatan yang ramah untuk semua siswa.'
},
{
  number: 11,
  name: 'Kota dan Permukiman yang Berkelanjutan',
  short: 'Mewujudkan kota dan permukiman yang inklusif, aman, tangguh, dan berkelanjutan.',
  color: '#FD9D24',
  darkText: true,
  image: "/183f2265-1a0e-411b-879a-2783c1e4183d.jpg",
  icon: Building2Icon,
  studentLink: 'Lingkungan sekolah dan sekitarnya adalah ruang hidup bersama yang perlu aman dan nyaman.',
  contributions: [
  'Menjaga fasilitas umum',
  'Berjalan kaki atau bersepeda bila memungkinkan',
  'Tertib di jalan sekitar sekolah'],

  osisExample: 'Kegiatan peduli lingkungan sekitar sekolah atau kampanye tertib lalu lintas.'
},
{
  number: 12,
  name: 'Konsumsi dan Produksi yang Bertanggung Jawab',
  short: 'Memastikan pola konsumsi dan produksi yang berkelanjutan.',
  color: '#BF8B2E',
  darkText: true,
  image: "/3308c680-d69d-4d12-9440-c5b1d5a08602.jpg",
  icon: RecycleIcon,
  studentLink: 'Kebiasaan jajan dan berbelanja pelajar memengaruhi jumlah sampah yang dihasilkan.',
  contributions: [
  'Membawa botol minum dan kotak makan sendiri',
  'Memilah sampah organik dan anorganik',
  'Menggunakan barang sampai benar-benar habis'],

  osisExample: 'Bank sampah sekolah atau gerakan mengurangi plastik sekali pakai.'
},
{
  number: 13,
  name: 'Penanganan Perubahan Iklim',
  short: 'Mengambil tindakan segera untuk mengatasi perubahan iklim dan dampaknya.',
  color: '#3F7E44',
  image: "/350d5282-b7e9-41b8-ae69-255b1cd8feea.jpg",
  icon: GlobeIcon,
  studentLink: 'Pelajar akan hidup paling lama dengan dampak perubahan iklim, jadi penting memahaminya sejak sekarang.',
  contributions: ['Menanam pohon', 'Mengurangi penggunaan plastik', 'Mengajak keluarga hemat energi'],
  osisExample: 'Peringatan Hari Bumi atau kampanye aksi iklim sederhana.'
},
{
  number: 14,
  name: 'Ekosistem Lautan',
  short: 'Melestarikan dan memanfaatkan sumber daya laut secara berkelanjutan.',
  color: '#0A97D9',
  darkText: true,
  image: "/d9039ba8-8c23-4f64-801e-30f51fcb894c.jpg",
  icon: FishIcon,
  studentLink: 'Sampah dari darat, termasuk dari sekolah, bisa berakhir di laut dan merusak ekosistemnya.',
  contributions: [
  'Tidak membuang sampah ke saluran air',
  'Mengurangi plastik sekali pakai',
  'Mempelajari ekosistem laut Indonesia'],

  osisExample: 'Edukasi tentang sampah plastik dan dampaknya bagi laut.'
},
{
  number: 15,
  name: 'Ekosistem Daratan',
  short: 'Melindungi, memulihkan, dan menjaga ekosistem daratan serta keanekaragaman hayati.',
  color: '#56C02B',
  darkText: true,
  image: "/60cdb4b4-2718-49da-8180-9327a50ee88b.jpg",
  icon: TreesIcon,
  studentLink: 'Tanaman dan pepohonan di sekolah adalah bagian kecil dari ekosistem daratan yang bisa dirawat siswa.',
  contributions: [
  'Merawat tanaman di kelas dan taman sekolah',
  'Tidak merusak tanaman',
  'Mengenal jenis tumbuhan di sekitar'],

  osisExample: 'Gerakan sekolah hijau atau adopsi tanaman per kelas.',
  priority: true
},
{
  number: 16,
  name: 'Perdamaian, Keadilan dan Kelembagaan yang Tangguh',
  short: 'Mendorong masyarakat yang damai, akses keadilan, serta kelembagaan yang efektif dan inklusif.',
  color: '#00689D',
  image: "/2449089b-b9e5-4676-ba9a-a3b11b8cceb2.jpg",
  icon: LandmarkIcon,
  studentLink: 'Sekolah yang aman, adil, dan terbuka dimulai dari cara siswa saling menghargai dan berorganisasi.',
  contributions: [
  'Menyelesaikan masalah dengan diskusi',
  'Ikut memilih dalam pemilihan ketua OSIS',
  'Berani menyampaikan pendapat dengan santun'],

  osisExample: 'Pemilihan ketua OSIS yang jujur dan musyawarah yang terbuka.'
},
{
  number: 17,
  name: 'Kemitraan untuk Mencapai Tujuan',
  short: 'Memperkuat kemitraan global untuk mencapai pembangunan berkelanjutan.',
  color: '#19486A',
  image: "/434667ab-ea20-4e1b-adfb-876f2d4102ad.jpg",
  icon: HandshakeIcon,
  studentLink: 'Perubahan besar lebih mudah dicapai jika pelajar mau bekerja sama dengan banyak pihak.',
  contributions: ['Bekerja sama lintas kelas', 'Melibatkan guru dan orang tua', 'Berkolaborasi dengan komunitas sekitar'],
  osisExample: 'Kolaborasi OSIS dengan ekstrakurikuler, guru, atau komunitas sekitar sekolah.',
  priority: true
}];