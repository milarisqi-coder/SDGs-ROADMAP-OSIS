import type { NavTab } from '../types/content';

export const navTabs: NavTab[] = [
{ id: 'beranda', label: 'Beranda' },
{ id: 'mengapa', label: 'Mengapa Ada?' },
{ id: 'sdgs', label: '17 SDGs' },
{ id: 'prioritas', label: '6 Prioritas SDGs' },
{ id: 'pelajar', label: 'Kenapa Pelajar Perlu Tahu?' },
{ id: 'struktur', label: 'Struktur OSIS' },
{ id: 'program', label: 'Program Kerja' },
{ id: 'roadmap', label: 'Roadmap OSIS' },
{ id: 'handbook', label: 'Handbook OSIS' }];