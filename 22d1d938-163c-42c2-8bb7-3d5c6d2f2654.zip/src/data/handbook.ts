import type { HandbookChapter, HandbookResource } from '../types/content';

export const handbookChapters: HandbookChapter[] = [
{
  id: 'bab-1',
  bab: 1,
  title: 'Mengenal SDGs',
  summary: 'Apa itu SDGs, mengapa dibuat, dan mengapa relevan untuk sekolah.',
  points: ['Pengertian Sustainable Development Goals', 'Sejarah singkat dan target tahun 2030', 'SDGs dalam kehidupan sehari-hari pelajar'],
  relatedTab: 'sdgs'
},
{
  id: 'bab-2',
  bab: 2,
  title: '17 Tujuan SDGs',
  summary: 'Penjelasan singkat setiap tujuan dengan bahasa yang mudah dipahami.',
  points: ['Ringkasan 17 tujuan', 'Contoh kontribusi siswa untuk setiap tujuan', 'Hubungan antar tujuan'],
  relatedTab: 'sdgs'
},
{
  id: 'bab-3',
  bab: 3,
  title: '6 Prioritas SDGs OSIS',
  summary: 'Enam tujuan yang menjadi fokus pemetaan program OSIS.',
  points: ['Alasan pemilihan 6 prioritas', 'Hubungan setiap prioritas dengan pelajar dan OSIS', 'Contoh bentuk aksi'],
  relatedTab: 'prioritas'
},
{
  id: 'bab-4',
  bab: 4,
  title: 'Mengapa Pelajar Perlu Mengetahui SDGs?',
  summary: 'Peran pelajar sebagai student changemaker di lingkungan sekolah.',
  points: ['Dari peserta menjadi penggerak', 'Alur Know – Understand – Think – Act – Impact', 'Aksi sederhana yang berdampak'],
  relatedTab: 'pelajar'
},
{
  id: 'bab-5',
  bab: 5,
  title: 'Cara Memetakan Program OSIS',
  summary: 'Langkah menghubungkan program kerja dengan SDGs yang relevan.',
  points: ['Mendaftar program kerja', 'Menentukan SDGs terkait', 'Contoh format tabel pemetaan'],
  relatedTab: 'program'
},
{
  id: 'bab-6',
  bab: 6,
  title: 'Menyusun Program Berbasis SDGs',
  summary: 'Menentukan tujuan, sasaran, indikator, dan timeline program.',
  points: ['Menulis tujuan yang jelas', 'Menyusun indikator keberhasilan', 'Membagi tugas dan timeline'],
  relatedTab: 'roadmap'
},
{
  id: 'bab-7',
  bab: 7,
  title: 'Monitoring dan Evaluasi',
  summary: 'Mencatat progress dan menilai hasil program secara sederhana.',
  points: ['Cara mencatat progress', 'Format evaluasi sederhana', 'Mengumpulkan masukan peserta'],
  relatedTab: 'roadmap'
},
{
  id: 'bab-8',
  bab: 8,
  title: 'Dokumentasi dan Lessons Learned',
  summary: 'Menyimpan pengalaman agar dapat dipelajari generasi berikutnya.',
  points: ['Apa saja yang perlu didokumentasikan', 'Menulis lessons learned', 'Menyimpan arsip di website'],
  relatedTab: 'program'
},
{
  id: 'bab-9',
  bab: 9,
  title: 'Regenerasi dan Transfer Knowledge',
  summary: 'Meneruskan pengetahuan dari satu kepengurusan ke kepengurusan berikutnya.',
  points: ['Persiapan serah terima', 'Memperbarui struktur OSIS', 'Menyerahkan handbook dan arsip program'],
  relatedTab: 'struktur'
}];


export const handbookResources: HandbookResource[] = [
{ id: 'res-1', title: '[Template Proposal Program]', note: 'Unggah file template melalui Edit Mode.' },
{ id: 'res-2', title: '[Format Laporan Evaluasi]', note: 'Unggah file template melalui Edit Mode.' }];