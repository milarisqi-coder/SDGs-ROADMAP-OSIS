import type { Program } from '../types/program';

const templateFields = {
  background: '[Tuliskan alasan program ini dibuat — masalah apa yang ingin diselesaikan di sekolah?]',
  goal: '[Tuliskan apa yang ingin dicapai melalui program ini.]',
  pic: '[Nama Penanggung Jawab]',
  target: '[Siapa yang menjadi sasaran? Contoh: siswa kelas 7–9]',
  indicators: ['[Indikator keberhasilan 1]', '[Indikator keberhasilan 2]'],
  period: '[Bulan mulai – Bulan selesai]',
  documentation: ['[Tautan foto kegiatan]', '[Tautan laporan kegiatan]'],
  evaluation: '[Apa yang sudah berjalan baik dan apa yang perlu diperbaiki?]',
  obstacles: '[Kendala yang dihadapi selama program berjalan.]',
  solutions: '[Cara yang dilakukan untuk mengatasi kendala.]',
  lessons: '[Pelajaran penting yang perlu diketahui pengurus berikutnya.]',
  development: '[Ide pengembangan program untuk periode berikutnya.]'
};

export const initialPrograms: Program[] = [
{
  id: 'prog-01',
  name: '[Program OSIS 01]',
  division: 'Seksi Akademik, Seni & Olahraga',
  year: '2026',
  sdgs: [4, 17],
  status: 'Berjalan',
  progress: 55,
  summary: '[Contoh template program bertema literasi dan belajar bersama — ganti dengan ringkasan program yang sebenarnya.]',
  ...templateFields
},
{
  id: 'prog-02',
  name: '[Program OSIS 02]',
  division: 'Seksi Kesehatan & Lingkungan Hidup',
  year: '2026',
  sdgs: [3],
  status: 'Selesai',
  progress: 100,
  summary: '[Contoh template program bertema kesehatan siswa — ganti dengan ringkasan program yang sebenarnya.]',
  ...templateFields
},
{
  id: 'prog-03',
  name: '[Program OSIS 03]',
  division: 'Seksi Kesehatan & Lingkungan Hidup',
  year: '2026',
  sdgs: [15],
  status: 'Perlu Evaluasi',
  progress: 80,
  summary: '[Contoh template program bertema lingkungan hijau sekolah — ganti dengan ringkasan program yang sebenarnya.]',
  ...templateFields
},
{
  id: 'prog-04',
  name: '[Program OSIS 04]',
  division: 'Seksi Kewirausahaan & Keterampilan',
  year: '2026',
  sdgs: [8, 17],
  status: 'Berjalan',
  progress: 35,
  summary: '[Contoh template program bertema kewirausahaan siswa — ganti dengan ringkasan program yang sebenarnya.]',
  ...templateFields
},
{
  id: 'prog-05',
  name: '[Program OSIS 05]',
  division: 'Seksi Budi Pekerti & Kepribadian',
  year: '2026',
  sdgs: [1, 17],
  status: 'Selesai',
  progress: 100,
  summary: '[Contoh template program bertema kepedulian sosial — ganti dengan ringkasan program yang sebenarnya.]',
  ...templateFields
},
{
  id: 'prog-06',
  name: '[Program OSIS 06]',
  division: 'Seksi Akademik, Seni & Olahraga',
  year: '2026',
  sdgs: [3, 4],
  status: 'Perlu Evaluasi',
  progress: 70,
  summary: '[Contoh template program bertema pengembangan diri siswa — ganti dengan ringkasan program yang sebenarnya.]',
  ...templateFields
}];