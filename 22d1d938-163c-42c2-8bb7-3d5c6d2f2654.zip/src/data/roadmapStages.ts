import {
  GraduationCapIcon,
  SearchIcon,
  MapIcon,
  ClipboardListIcon,
  FlagIcon,
  ActivityIcon,
  ClipboardCheckIcon,
  RefreshCwIcon } from
'lucide-react';
import type { RoadmapStage } from '../types/content';

export const roadmapStages: RoadmapStage[] = [
{
  number: '01',
  code: 'KNOW',
  title: 'Mengenal SDGs',
  summary: 'Siswa mengenal 17 SDGs dan memahami tujuan pembangunan berkelanjutan.',
  explanation:
  'Tahap awal untuk membangun pemahaman bersama. Pengurus dan siswa mengenal 17 SDGs, alasan SDGs dibuat, dan bagaimana tujuan global terasa dekat dengan kehidupan di sekolah.',
  goal: 'Semua pengurus memiliki pemahaman dasar yang sama tentang SDGs.',
  activities: [
  'Mempelajari 17 SDGs melalui website dan handbook',
  'Berdiskusi tentang SDGs yang paling dekat dengan sekolah',
  'Mengenalkan 6 prioritas SDGs OSIS'],

  output: 'Pengurus memahami 17 SDGs dan 6 prioritas SDGs OSIS.',
  example: 'Sesi pengenalan SDGs saat rapat perdana kepengurusan baru.',
  checklist: ['Sudah membaca Bab 1–3 handbook', 'Mengetahui 6 prioritas SDGs OSIS', 'Dapat menjelaskan SDGs dengan bahasa sendiri'],
  icon: GraduationCapIcon
},
{
  number: '02',
  code: 'UNDERSTAND',
  title: 'Memahami Masalah',
  summary: 'Siswa memahami masalah yang terjadi di lingkungan sekolah dan sekitarnya.',
  explanation:
  'Pengurus mengamati kondisi sekolah dan sekitarnya untuk menemukan masalah nyata yang dialami warga sekolah, bukan sekadar dugaan.',
  goal: 'Menemukan masalah yang benar-benar dirasakan warga sekolah.',
  activities: [
  'Mengamati lingkungan sekolah',
  'Mengumpulkan pendapat siswa melalui kotak saran atau survei sederhana',
  'Mencatat masalah yang paling sering muncul'],

  output: 'Daftar masalah prioritas di lingkungan sekolah.',
  example: 'Survei singkat ke setiap kelas tentang masalah yang paling dirasakan siswa.',
  checklist: ['Masalah dicatat dengan jelas', 'Ada masukan dari siswa di luar pengurus', 'Masalah sudah diurutkan berdasarkan prioritas'],
  icon: SearchIcon
},
{
  number: '03',
  code: 'MAP',
  title: 'Memetakan Program',
  summary: 'Program kerja OSIS dihubungkan dengan SDGs yang relevan.',
  explanation:
  'Program kerja OSIS, baik yang sudah ada maupun yang baru, dihubungkan dengan SDGs yang relevan sehingga setiap kegiatan punya arah yang jelas.',
  goal: 'Setiap program memiliki arah dan tujuan yang jelas.',
  activities: [
  'Mendaftar semua program kerja OSIS',
  'Menentukan SDGs yang terkait dengan setiap program',
  'Melihat masalah mana yang sudah dan belum dijawab oleh program'],

  output: 'Peta hubungan program OSIS dengan SDGs.',
  example: 'Tabel sederhana berisi nama program, seksi, dan SDGs terkait.',
  checklist: ['Semua program sudah terdaftar', 'Setiap program terhubung dengan minimal satu SDG', 'Peta program disimpan di halaman Program Kerja'],
  icon: MapIcon
},
{
  number: '04',
  code: 'PLAN',
  title: 'Merencanakan Program',
  summary: 'Menentukan tujuan, sasaran, indikator, timeline, dan sumber daya yang diperlukan.',
  explanation: 'Program dirancang lebih rinci agar mudah dijalankan, dibagi tugasnya, dan diukur hasilnya.',
  goal: 'Program siap dijalankan dengan rencana yang jelas.',
  activities: [
  'Menentukan tujuan dan sasaran',
  'Menyusun indikator keberhasilan',
  'Membuat timeline dan pembagian tugas',
  'Mendata sumber daya yang dibutuhkan'],

  output: 'Rencana program lengkap dalam bentuk proposal sederhana.',
  example: 'Rapat seksi untuk menyusun timeline dan menentukan penanggung jawab.',
  checklist: ['Tujuan dan sasaran tertulis', 'Indikator keberhasilan dapat diukur', 'Timeline dan penanggung jawab sudah jelas'],
  icon: ClipboardListIcon
},
{
  number: '05',
  code: 'ACT',
  title: 'Menjalankan Aksi',
  summary: 'Program dilaksanakan sesuai rencana dengan melibatkan warga sekolah.',
  explanation: 'Program dijalankan sesuai rencana dengan melibatkan siswa, guru, dan warga sekolah lainnya.',
  goal: 'Program terlaksana dan memberi manfaat bagi warga sekolah.',
  activities: [
  'Melaksanakan kegiatan sesuai timeline',
  'Melibatkan warga sekolah sebagai peserta dan mitra',
  'Mendokumentasikan kegiatan: foto, catatan, dan daftar hadir'],

  output: 'Kegiatan terlaksana beserta dokumentasinya.',
  example: 'Pelaksanaan kegiatan dengan petugas dokumentasi yang sudah ditunjuk.',
  checklist: ['Kegiatan berjalan sesuai rencana', 'Ada dokumentasi foto dan catatan', 'Peserta dan mitra tercatat'],
  icon: FlagIcon
},
{
  number: '06',
  code: 'MONITOR',
  title: 'Memantau Perkembangan',
  summary: 'Mencatat progress, capaian, kendala, dan perkembangan program.',
  explanation: 'Selama program berjalan, pengurus mencatat perkembangan agar kendala cepat diketahui dan ditangani.',
  goal: 'Mengetahui apakah program berjalan sesuai rencana.',
  activities: ['Mencatat progress secara berkala', 'Mencatat kendala yang muncul', 'Memperbarui status program di website'],
  output: 'Catatan progress dan kendala program.',
  example: 'Update progress singkat di setiap rapat mingguan.',
  checklist: ['Progress diperbarui secara rutin', 'Kendala dicatat beserta tanggalnya', 'Status program di website sudah sesuai'],
  icon: ActivityIcon
},
{
  number: '07',
  code: 'EVALUATE',
  title: 'Mengevaluasi',
  summary: 'Melihat apa yang sudah berjalan baik, apa yang perlu diperbaiki, dan apa yang dapat dikembangkan.',
  explanation:
  'Setelah program selesai, pengurus melihat kembali apa yang berjalan baik, apa yang perlu diperbaiki, dan apa yang dapat dikembangkan.',
  goal: 'Mendapat pelajaran untuk memperbaiki dan mengembangkan program.',
  activities: [
  'Membandingkan hasil dengan indikator keberhasilan',
  'Mengumpulkan masukan dari peserta',
  'Menuliskan hambatan dan solusinya'],

  output: 'Catatan evaluasi dan rekomendasi pengembangan.',
  example: 'Rapat evaluasi bersama setelah kegiatan selesai.',
  checklist: ['Hasil dibandingkan dengan indikator', 'Ada masukan dari peserta', 'Rekomendasi pengembangan sudah tertulis'],
  icon: ClipboardCheckIcon
},
{
  number: '08',
  code: 'REGENERATE',
  title: 'Mewariskan Pengetahuan',
  summary: 'Dokumentasi, pengalaman, evaluasi, dan lessons learned diteruskan kepada pengurus OSIS berikutnya.',
  explanation:
  'Semua dokumentasi, pengalaman, dan pelajaran diserahkan kepada pengurus berikutnya agar program tidak dimulai dari nol.',
  goal: 'Pengurus berikutnya dapat melanjutkan dan mengembangkan program.',
  activities: [
  'Melengkapi lessons learned di setiap program',
  'Memperbarui handbook dan struktur OSIS',
  'Mengadakan sesi serah terima dengan pengurus baru'],

  output: 'Arsip program dan handbook yang siap digunakan generasi berikutnya.',
  example: 'Sesi serah terima pengetahuan saat pergantian kepengurusan.',
  checklist: ['Lessons learned setiap program terisi', 'Struktur OSIS periode baru diperbarui', 'Serah terima sudah dilakukan'],
  icon: RefreshCwIcon
}];