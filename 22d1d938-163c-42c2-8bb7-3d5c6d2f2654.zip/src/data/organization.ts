import type { Organization } from '../types/organization';

export const initialPeriod = '2026';

export const initialOrganization: Organization = {
  core: {
    pembina: { id: 'core-pembina', name: '[Nama Pembina]', position: 'Pembina OSIS', divisionId: 'inti', period: '2026', photo: '' },
    ketua: { id: 'core-ketua', name: '[Nama Ketua]', position: 'Ketua OSIS', divisionId: 'inti', period: '2026', photo: '' },
    wakil: { id: 'core-wakil', name: '[Nama Wakil Ketua]', position: 'Wakil Ketua OSIS', divisionId: 'inti', period: '2026', photo: '' },
    sekretaris: { id: 'core-sekretaris', name: '[Nama Sekretaris]', position: 'Sekretaris', divisionId: 'inti', period: '2026', photo: '' },
    bendahara: { id: 'core-bendahara', name: '[Nama Bendahara]', position: 'Bendahara', divisionId: 'inti', period: '2026', photo: '' }
  },
  divisions: [
  {
    id: 'div-1',
    name: 'Seksi Keimanan & Ketakwaan',
    members: [
    { id: 'm-1a', name: '[Nama Koordinator Seksi]', position: 'Koordinator Seksi', divisionId: 'div-1', period: '2026', photo: '' },
    { id: 'm-1b', name: '[Nama Anggota]', position: 'Anggota', divisionId: 'div-1', period: '2026', photo: '' }]

  },
  {
    id: 'div-2',
    name: 'Seksi Budi Pekerti & Kepribadian',
    members: [
    { id: 'm-2a', name: '[Nama Koordinator Seksi]', position: 'Koordinator Seksi', divisionId: 'div-2', period: '2026', photo: '' },
    { id: 'm-2b', name: '[Nama Anggota]', position: 'Anggota', divisionId: 'div-2', period: '2026', photo: '' }]

  },
  {
    id: 'div-3',
    name: 'Seksi Kebangsaan & Kepemimpinan',
    members: [
    { id: 'm-3a', name: '[Nama Koordinator Seksi]', position: 'Koordinator Seksi', divisionId: 'div-3', period: '2026', photo: '' },
    { id: 'm-3b', name: '[Nama Anggota]', position: 'Anggota', divisionId: 'div-3', period: '2026', photo: '' }]

  },
  {
    id: 'div-4',
    name: 'Seksi Akademik, Seni & Olahraga',
    members: [
    { id: 'm-4a', name: '[Nama Koordinator Seksi]', position: 'Koordinator Seksi', divisionId: 'div-4', period: '2026', photo: '' },
    { id: 'm-4b', name: '[Nama Anggota]', position: 'Anggota', divisionId: 'div-4', period: '2026', photo: '' }]

  },
  {
    id: 'div-5',
    name: 'Seksi Kewirausahaan & Keterampilan',
    members: [
    { id: 'm-5a', name: '[Nama Koordinator Seksi]', position: 'Koordinator Seksi', divisionId: 'div-5', period: '2026', photo: '' },
    { id: 'm-5b', name: '[Nama Anggota]', position: 'Anggota', divisionId: 'div-5', period: '2026', photo: '' }]

  },
  {
    id: 'div-6',
    name: 'Seksi Kesehatan & Lingkungan Hidup',
    members: [
    { id: 'm-6a', name: '[Nama Koordinator Seksi]', position: 'Koordinator Seksi', divisionId: 'div-6', period: '2026', photo: '' },
    { id: 'm-6b', name: '[Nama Anggota]', position: 'Anggota', divisionId: 'div-6', period: '2026', photo: '' }]

  }]

};