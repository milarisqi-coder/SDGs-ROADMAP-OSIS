import type { PriorityDetail } from '../types/content';

export const prioritySdgs: PriorityDetail[] = [
{
  number: 1,
  tagline: 'Peduli dan berbagi dengan sesama',
  goal: 'SDG 1 bertujuan mengakhiri kemiskinan dalam segala bentuk — bukan hanya soal uang, tetapi juga akses terhadap pendidikan, kesehatan, dan kebutuhan dasar.',
  studentLink:
  'Pelajar dapat melatih kepekaan sosial: menyadari bahwa tidak semua teman memiliki kondisi yang sama, lalu belajar membantu dengan cara yang menghargai.',
  osisLink:
  'OSIS dapat menjadi penggerak kegiatan sosial yang terorganisasi, transparan, dan melibatkan seluruh warga sekolah.',
  contributionExample: 'Mengumpulkan buku dan seragam layak pakai untuk teman yang membutuhkan.',
  actions: [
  'Donasi buku dan alat tulis layak pakai',
  'Kegiatan berbagi di lingkungan sekitar sekolah',
  'Kampanye empati dan saling menghargai',
  'Pendataan kebutuhan secara bijak dan menjaga privasi']

},
{
  number: 3,
  tagline: 'Siswa sehat, belajar lebih semangat',
  goal: 'SDG 3 bertujuan menjamin kehidupan yang sehat dan mendorong kesejahteraan fisik maupun mental untuk semua usia.',
  studentLink:
  'Kesehatan tubuh dan pikiran memengaruhi konsentrasi, semangat belajar, dan hubungan pertemanan di sekolah.',
  osisLink:
  'OSIS dapat mengajak siswa membangun kebiasaan sehat dan menciptakan lingkungan sekolah yang aman dan saling mendukung.',
  contributionExample: 'Mengajak teman sekelas berolahraga ringan dan membawa bekal sehat.',
  actions: ['Senam atau olahraga bersama', 'Kampanye jajanan sehat', 'Ruang cerita dan dukungan teman sebaya', 'Gerakan kelas bersih']
},
{
  number: 4,
  tagline: 'Belajar bersama, tumbuh bersama',
  goal: 'SDG 4 bertujuan memastikan pendidikan yang inklusif dan berkualitas, serta kesempatan belajar sepanjang hayat bagi semua.',
  studentLink:
  'Pelajar bukan hanya penerima pendidikan. Mereka juga bisa saling mengajar, berbagi bacaan, dan membangun budaya literasi.',
  osisLink:
  'OSIS dapat mendukung kegiatan literasi, belajar kelompok, dan pengembangan diri siswa di luar jam pelajaran.',
  contributionExample: 'Menjadi tutor sebaya untuk teman yang kesulitan memahami materi.',
  actions: ['Pojok baca kelas', 'Kelompok belajar dan tutor sebaya', 'Kelas berbagi keterampilan', 'Lomba literasi']
},
{
  number: 8,
  tagline: 'Kreatif, terampil, dan mandiri',
  goal: 'SDG 8 bertujuan mendorong pertumbuhan ekonomi yang inklusif serta pekerjaan yang layak bagi semua orang.',
  studentLink:
  'Sejak SMP, pelajar dapat melatih kreativitas, tanggung jawab, kerja sama, dan keterampilan yang berguna untuk masa depan.',
  osisLink:
  'OSIS dapat memberi ruang bagi siswa untuk belajar berwirausaha, mengelola kegiatan, dan mengasah keterampilan.',
  contributionExample: 'Membuat dan memasarkan produk kreatif sederhana bersama teman.',
  actions: [
  'Bazar kewirausahaan siswa',
  'Pelatihan keterampilan seperti desain dan public speaking',
  'Pengelolaan kas kegiatan yang tertib',
  'Pameran karya siswa']

},
{
  number: 15,
  tagline: 'Sekolah hijau, bumi terjaga',
  goal: 'SDG 15 bertujuan melindungi, memulihkan, dan menjaga ekosistem daratan, hutan, serta keanekaragaman hayati.',
  studentLink:
  'Taman, pohon, dan tanaman di sekolah adalah ekosistem kecil yang bisa dirawat dan dipelajari langsung oleh siswa.',
  osisLink:
  'OSIS dapat menggerakkan kepedulian lingkungan dan merawat ruang hijau sekolah bersama seluruh warga sekolah.',
  contributionExample: 'Merawat tanaman kelas secara bergiliran.',
  actions: ['Penanaman pohon', 'Adopsi tanaman per kelas', 'Kebun sekolah', 'Pengenalan tumbuhan dan satwa lokal']
},
{
  number: 17,
  tagline: 'Bergerak bersama, melangkah lebih jauh',
  goal: 'SDG 17 bertujuan memperkuat kerja sama berbagai pihak untuk mencapai pembangunan berkelanjutan.',
  studentLink:
  'Banyak masalah tidak bisa diselesaikan sendiri. Pelajar belajar bekerja sama lintas kelas, dengan guru, dan dengan pihak luar sekolah.',
  osisLink:
  'OSIS dapat menjadi penghubung antara siswa, guru, ekstrakurikuler, orang tua, dan komunitas di sekitar sekolah.',
  contributionExample: 'Mengajak ekstrakurikuler lain berkolaborasi dalam satu kegiatan.',
  actions: [
  'Kolaborasi OSIS dengan ekstrakurikuler',
  'Kegiatan bersama guru dan orang tua',
  'Kerja sama dengan komunitas sekitar',
  'Forum diskusi antarkelas']

}];