import {
  LayersIcon,
  TargetIcon,
  FlagIcon,
  HeartHandshakeIcon,
  RefreshCwIcon,
  UnlinkIcon,
  ArchiveXIcon,
  RotateCcwIcon,
  SearchIcon,
  LightbulbIcon,
  CompassIcon,
  MegaphoneIcon,
  SproutIcon,
  EyeIcon,
  BrainIcon,
  RocketIcon,
  TrendingUpIcon } from
'lucide-react';
import type { FlowStep, InfoCard, TabId } from '../types/content';

export const homeFlow: FlowStep[] = [
{ label: 'PROGRAM', caption: 'Kegiatan OSIS yang sudah ada', icon: LayersIcon },
{ label: 'SDGs', caption: 'Dihubungkan dengan tujuan global', icon: TargetIcon },
{ label: 'AKSI', caption: 'Dijalankan bersama warga sekolah', icon: FlagIcon },
{ label: 'DAMPAK', caption: 'Manfaat yang benar-benar dirasakan', icon: HeartHandshakeIcon },
{ label: 'REGENERASI', caption: 'Diteruskan ke generasi berikutnya', icon: RefreshCwIcon }];


export const conceptLines: {text: string;tab: TabId;}[] = [
{ text: 'Know the SDGs.', tab: 'sdgs' },
{ text: 'Map the Programs.', tab: 'program' },
{ text: 'Create the Impact.', tab: 'roadmap' },
{ text: 'Continue the Change.', tab: 'handbook' }];


export const problemCards: InfoCard[] = [
{
  number: '01',
  title: 'Program Belum Terpetakan',
  body: 'Program OSIS belum selalu memiliki hubungan yang jelas dengan tujuan pembangunan berkelanjutan.',
  icon: UnlinkIcon
},
{
  number: '02',
  title: 'Pengetahuan Bisa Hilang',
  body: 'Pengalaman, hambatan, solusi, dan pembelajaran dari suatu program dapat ikut hilang ketika kepengurusan berganti.',
  icon: ArchiveXIcon
},
{
  number: '03',
  title: 'Sulit Dilanjutkan',
  body: 'Tanpa dokumentasi yang baik, pengurus berikutnya harus kembali mencari tahu dari awal.',
  icon: RotateCcwIcon
}];


export const solutionFlow: FlowStep[] = [
{ label: 'KENALI', caption: 'SDGs dan tujuannya' },
{ label: 'PAHAMI', caption: 'Masalah di sekitar' },
{ label: 'PETAKAN', caption: 'Program ke SDGs' },
{ label: 'JALANKAN', caption: 'Aksi bersama' },
{ label: 'KEMBANGKAN', caption: 'Dari hasil evaluasi' },
{ label: 'LANJUTKAN', caption: 'Oleh generasi baru' }];


export const studentReasons: InfoCard[] = [
{
  number: '01',
  title: 'Memahami Masalah',
  body: 'SDGs membantu siswa memahami berbagai masalah sosial, kesehatan, pendidikan, ekonomi, dan lingkungan.',
  icon: SearchIcon
},
{
  number: '02',
  title: 'Menemukan Ide',
  body: 'Dengan memahami masalah, siswa dapat menemukan ide dan solusi yang relevan dengan lingkungan sekitar.',
  icon: LightbulbIcon
},
{
  number: '03',
  title: 'Kegiatan Lebih Terarah',
  body: 'SDGs membantu OSIS melihat tujuan dan dampak dari kegiatan yang dilakukan.',
  icon: CompassIcon
},
{
  number: '04',
  title: 'Menjadi Student Changemaker',
  body: 'Siswa tidak hanya menjadi peserta kegiatan, tetapi dapat menjadi bagian dari perubahan.',
  icon: MegaphoneIcon
},
{
  number: '05',
  title: 'Belajar untuk Berkelanjutan',
  body: 'Setiap pengalaman dapat menjadi pembelajaran yang diteruskan oleh generasi berikutnya.',
  icon: SproutIcon
}];


export const studentFlow: FlowStep[] = [
{ label: 'KNOW', caption: 'Mengenal', icon: EyeIcon },
{ label: 'UNDERSTAND', caption: 'Memahami', icon: BrainIcon },
{ label: 'THINK', caption: 'Mencari ide', icon: LightbulbIcon },
{ label: 'ACT', caption: 'Bertindak', icon: RocketIcon },
{ label: 'IMPACT', caption: 'Memberi dampak', icon: TrendingUpIcon }];