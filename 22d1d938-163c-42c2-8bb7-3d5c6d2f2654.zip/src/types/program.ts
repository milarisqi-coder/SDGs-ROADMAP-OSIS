export type ProgramStatus = 'Berjalan' | 'Selesai' | 'Perlu Evaluasi';

export interface Program {
  id: string;
  name: string;
  division: string;
  year: string;
  sdgs: number[];
  status: ProgramStatus;
  summary: string;
  background: string;
  goal: string;
  pic: string;
  target: string;
  indicators: string[];
  period: string;
  progress: number;
  documentation: string[];
  evaluation: string;
  obstacles: string;
  solutions: string;
  lessons: string;
  development: string;
}