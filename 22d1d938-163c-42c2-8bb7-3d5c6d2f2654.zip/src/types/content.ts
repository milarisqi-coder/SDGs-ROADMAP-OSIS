import type { LucideIcon } from 'lucide-react';

export type TabId =
'beranda' |
'mengapa' |
'sdgs' |
'prioritas' |
'pelajar' |
'struktur' |
'program' |
'roadmap' |
'handbook';

export interface NavTab {
  id: TabId;
  label: string;
}

export interface Sdg {
  number: number;
  name: string;
  short: string;
  color: string;
  darkText?: boolean;
  image: string;
  icon: LucideIcon;
  studentLink: string;
  contributions: string[];
  osisExample: string;
  priority?: boolean;
}

export interface PriorityDetail {
  number: number;
  tagline: string;
  goal: string;
  studentLink: string;
  osisLink: string;
  contributionExample: string;
  actions: string[];
}

export interface FlowStep {
  label: string;
  caption?: string;
  icon?: LucideIcon;
}

export interface InfoCard {
  number: string;
  title: string;
  body: string;
  icon: LucideIcon;
}

export interface RoadmapStage {
  number: string;
  code: string;
  title: string;
  summary: string;
  explanation: string;
  goal: string;
  activities: string[];
  output: string;
  example: string;
  checklist: string[];
  icon: LucideIcon;
}

export interface HandbookChapter {
  id: string;
  bab: number;
  title: string;
  summary: string;
  points: string[];
  relatedTab: TabId;
}

export interface HandbookResource {
  id: string;
  title: string;
  note: string;
}