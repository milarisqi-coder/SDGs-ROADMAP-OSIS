export type CoreRole = 'pembina' | 'ketua' | 'wakil' | 'sekretaris' | 'bendahara';

export const CORE_DIVISION_ID = 'inti';

export interface Member {
  id: string;
  name: string;
  position: string;
  divisionId: string;
  period: string;
  photo: string;
}

export interface Division {
  id: string;
  name: string;
  members: Member[];
}

export interface Organization {
  core: Record<CoreRole, Member>;
  divisions: Division[];
}