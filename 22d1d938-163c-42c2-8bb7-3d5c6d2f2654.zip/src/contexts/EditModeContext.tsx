import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';

interface EditMeta {
  lastUpdated: Date;
  updatedBy: string;
}

interface EditModeValue {
  isEditing: boolean;
  editorName: string;
  meta: EditMeta;
  accessOpen: boolean;
  requestEditMode: () => void;
  closeAccess: () => void;
  enableEditMode: (name: string) => void;
  disableEditMode: () => void;
  markUpdated: () => void;
}

const EditModeContext = createContext<EditModeValue | null>(null);

export function EditModeProvider({ children }: {children: React.ReactNode;}) {
  const [isEditing, setIsEditing] = useState(false);
  const [editorName, setEditorName] = useState('');
  const [accessOpen, setAccessOpen] = useState(false);
  const [meta, setMeta] = useState<EditMeta>({
    lastUpdated: new Date(2026, 8, 23, 9, 0),
    updatedBy: '[Nama Admin OSIS]'
  });

  const requestEditMode = useCallback(() => setAccessOpen(true), []);
  const closeAccess = useCallback(() => setAccessOpen(false), []);

  const enableEditMode = useCallback((name: string) => {
    setEditorName(name);
    setIsEditing(true);
    setAccessOpen(false);
  }, []);

  const disableEditMode = useCallback(() => setIsEditing(false), []);

  const markUpdated = useCallback(() => {
    setMeta({ lastUpdated: new Date(), updatedBy: editorName || '[Nama Admin OSIS]' });
  }, [editorName]);

  const value = useMemo(
    () => ({
      isEditing,
      editorName,
      meta,
      accessOpen,
      requestEditMode,
      closeAccess,
      enableEditMode,
      disableEditMode,
      markUpdated
    }),
    [isEditing, editorName, meta, accessOpen, requestEditMode, closeAccess, enableEditMode, disableEditMode, markUpdated]
  );

  return <EditModeContext.Provider value={value}>{children}</EditModeContext.Provider>;
}

export function useEditMode(): EditModeValue {
  const ctx = useContext(EditModeContext);
  if (!ctx) throw new Error('useEditMode must be used within EditModeProvider');
  return ctx;
}