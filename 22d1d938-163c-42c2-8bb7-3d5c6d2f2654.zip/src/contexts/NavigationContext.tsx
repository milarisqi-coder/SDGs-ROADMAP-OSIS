import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import type { TabId } from '../types/content';

interface NavigationValue {
  activeTab: TabId;
  goTo: (tab: TabId) => void;
}

const NavigationContext = createContext<NavigationValue | null>(null);

export function NavigationProvider({ children }: {children: React.ReactNode;}) {
  const [activeTab, setActiveTab] = useState<TabId>('beranda');

  const goTo = useCallback((tab: TabId) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const value = useMemo(() => ({ activeTab, goTo }), [activeTab, goTo]);
  return <NavigationContext.Provider value={value}>{children}</NavigationContext.Provider>;
}

export function useNavigation(): NavigationValue {
  const ctx = useContext(NavigationContext);
  if (!ctx) throw new Error('useNavigation must be used within NavigationProvider');
  return ctx;
}