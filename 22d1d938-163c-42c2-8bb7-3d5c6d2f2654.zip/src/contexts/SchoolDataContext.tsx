import React, { createContext, useContext } from 'react';
import { useEditMode } from './EditModeContext';
import { useOrganization } from '../hooks/useOrganization';
import { usePrograms } from '../hooks/usePrograms';
import { useHandbookContent } from '../hooks/useHandbookContent';

type SchoolDataValue = ReturnType<typeof useOrganization> &
ReturnType<typeof usePrograms> &
ReturnType<typeof useHandbookContent>;

const SchoolDataContext = createContext<SchoolDataValue | null>(null);

export function SchoolDataProvider({ children }: {children: React.ReactNode;}) {
  const { markUpdated } = useEditMode();
  const organization = useOrganization(markUpdated);
  const programs = usePrograms(markUpdated);
  const handbook = useHandbookContent(markUpdated);

  const value: SchoolDataValue = { ...organization, ...programs, ...handbook };
  return <SchoolDataContext.Provider value={value}>{children}</SchoolDataContext.Provider>;
}

export function useSchoolData(): SchoolDataValue {
  const ctx = useContext(SchoolDataContext);
  if (!ctx) throw new Error('useSchoolData must be used within SchoolDataProvider');
  return ctx;
}