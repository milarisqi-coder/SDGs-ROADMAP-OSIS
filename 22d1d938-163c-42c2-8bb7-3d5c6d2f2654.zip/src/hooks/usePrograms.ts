import { useCallback, useState } from 'react';
import { initialPrograms } from '../data/programs';
import type { Program } from '../types/program';

export function usePrograms(onChange: () => void) {
  const [programs, setPrograms] = useState<Program[]>(initialPrograms);

  const saveProgram = useCallback(
    (program: Program) => {
      setPrograms((prev) =>
      prev.some((p) => p.id === program.id) ? prev.map((p) => p.id === program.id ? program : p) : [...prev, program]
      );
      onChange();
    },
    [onChange]
  );

  const deleteProgram = useCallback(
    (programId: string) => {
      setPrograms((prev) => prev.filter((p) => p.id !== programId));
      onChange();
    },
    [onChange]
  );

  return { programs, saveProgram, deleteProgram };
}