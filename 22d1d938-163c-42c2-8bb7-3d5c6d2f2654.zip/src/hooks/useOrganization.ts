import { useCallback, useState } from 'react';
import { initialOrganization, initialPeriod } from '../data/organization';
import type { CoreRole, Division, Member, Organization } from '../types/organization';

export function useOrganization(onChange: () => void) {
  const [organization, setOrganization] = useState<Organization>(initialOrganization);
  const [period, setPeriodState] = useState(initialPeriod);

  const setPeriod = useCallback(
    (value: string) => {
      setPeriodState(value);
      onChange();
    },
    [onChange]
  );

  const saveMember = useCallback(
    (member: Member) => {
      setOrganization((prev) => {
        const coreRole = (Object.keys(prev.core) as CoreRole[]).find((role) => prev.core[role].id === member.id);
        if (coreRole) return { ...prev, core: { ...prev.core, [coreRole]: member } };

        let keptIndex = -1;
        const stripped = prev.divisions.map((d) => {
          const i = d.members.findIndex((m) => m.id === member.id);
          if (i >= 0 && d.id === member.divisionId) keptIndex = i;
          return { ...d, members: d.members.filter((m) => m.id !== member.id) };
        });
        return {
          ...prev,
          divisions: stripped.map((d) => {
            if (d.id !== member.divisionId) return d;
            const members =
            keptIndex >= 0 ?
            [...d.members.slice(0, keptIndex), member, ...d.members.slice(keptIndex)] :
            [...d.members, member];
            return { ...d, members };
          })
        };
      });
      onChange();
    },
    [onChange]
  );

  const deleteMember = useCallback(
    (memberId: string) => {
      setOrganization((prev) => ({
        ...prev,
        divisions: prev.divisions.map((d) => ({ ...d, members: d.members.filter((m) => m.id !== memberId) }))
      }));
      onChange();
    },
    [onChange]
  );

  const moveMember = useCallback(
    (divisionId: string, memberId: string, direction: -1 | 1) => {
      setOrganization((prev) => ({
        ...prev,
        divisions: prev.divisions.map((d) => {
          if (d.id !== divisionId) return d;
          const i = d.members.findIndex((m) => m.id === memberId);
          const j = i + direction;
          if (i < 0 || j < 0 || j >= d.members.length) return d;
          const members = [...d.members];
          [members[i], members[j]] = [members[j], members[i]];
          return { ...d, members };
        })
      }));
      onChange();
    },
    [onChange]
  );

  const saveDivision = useCallback(
    (division: Pick<Division, 'id' | 'name'>) => {
      setOrganization((prev) => {
        const exists = prev.divisions.some((d) => d.id === division.id);
        return {
          ...prev,
          divisions: exists ?
          prev.divisions.map((d) => d.id === division.id ? { ...d, name: division.name } : d) :
          [...prev.divisions, { id: division.id, name: division.name, members: [] }]
        };
      });
      onChange();
    },
    [onChange]
  );

  const deleteDivision = useCallback(
    (divisionId: string) => {
      setOrganization((prev) => ({ ...prev, divisions: prev.divisions.filter((d) => d.id !== divisionId) }));
      onChange();
    },
    [onChange]
  );

  const moveDivision = useCallback(
    (divisionId: string, direction: -1 | 1) => {
      setOrganization((prev) => {
        const i = prev.divisions.findIndex((d) => d.id === divisionId);
        const j = i + direction;
        if (i < 0 || j < 0 || j >= prev.divisions.length) return prev;
        const divisions = [...prev.divisions];
        [divisions[i], divisions[j]] = [divisions[j], divisions[i]];
        return { ...prev, divisions };
      });
      onChange();
    },
    [onChange]
  );

  return { organization, period, setPeriod, saveMember, deleteMember, moveMember, saveDivision, deleteDivision, moveDivision };
}