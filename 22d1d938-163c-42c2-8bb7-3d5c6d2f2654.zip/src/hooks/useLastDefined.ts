import { useEffect, useState } from 'react';

/** Keeps the last non-null value so modal content stays visible during exit animations. */
export function useLastDefined<T>(value: T | null): T | null {
  const [last, setLast] = useState<T | null>(value);
  useEffect(() => {
    if (value !== null) setLast(value);
  }, [value]);
  return value ?? last;
}