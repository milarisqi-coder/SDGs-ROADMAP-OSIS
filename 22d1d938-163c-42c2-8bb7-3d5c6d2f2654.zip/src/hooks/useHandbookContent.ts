import { useCallback, useState } from 'react';
import { handbookChapters, handbookResources } from '../data/handbook';
import type { HandbookChapter, HandbookResource } from '../types/content';
import { makeId } from '../utils/text';

export function useHandbookContent(onChange: () => void) {
  const [chapters, setChapters] = useState<HandbookChapter[]>(handbookChapters);
  const [resources, setResources] = useState<HandbookResource[]>(handbookResources);

  const updateChapter = useCallback(
    (chapterId: string, patch: Pick<HandbookChapter, 'title' | 'summary'>) => {
      setChapters((prev) => prev.map((c) => c.id === chapterId ? { ...c, ...patch } : c));
      onChange();
    },
    [onChange]
  );

  const addResource = useCallback(
    (title: string, note: string) => {
      setResources((prev) => [...prev, { id: makeId('res'), title, note }]);
      onChange();
    },
    [onChange]
  );

  const removeResource = useCallback(
    (resourceId: string) => {
      setResources((prev) => prev.filter((r) => r.id !== resourceId));
      onChange();
    },
    [onChange]
  );

  return { chapters, resources, updateChapter, addResource, removeResource };
}