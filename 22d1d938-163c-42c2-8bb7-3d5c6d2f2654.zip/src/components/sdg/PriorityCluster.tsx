import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { getSdg } from '../../utils/sdg';

interface PriorityClusterProps {
  onSelect: (number: number) => void;
}

const nodes: {number: number;x: number;y: number;}[] = [
{ number: 1, x: 50, y: 12 },
{ number: 3, x: 15, y: 34 },
{ number: 4, x: 85, y: 34 },
{ number: 8, x: 15, y: 68 },
{ number: 15, x: 85, y: 68 },
{ number: 17, x: 50, y: 88 }];


const exampleLinks = [3, 4, 17];

export function PriorityCluster({ onSelect }: PriorityClusterProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const [showExample, setShowExample] = useState(false);

  const isLit = (n: number) => showExample ? exampleLinks.includes(n) : hovered === n;
  const anyLit = showExample || hovered !== null;

  return (
    <div>
      <div className="relative mx-auto h-[440px] w-full max-w-4xl sm:h-[480px]">
        <svg className="absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          {nodes.map((node) => {
            const lit = isLit(node.number);
            const sdg = getSdg(node.number);
            return (
              <line
                key={node.number}
                x1={50}
                y1={50}
                x2={node.x}
                y2={node.y}
                stroke={lit ? sdg.color : '#B3C3D8'}
                strokeWidth={lit ? 2.5 : 1.25}
                strokeDasharray={lit ? '0' : '4 4'}
                vectorEffect="non-scaling-stroke"
                style={{ transition: 'stroke 200ms ease-out, stroke-width 200ms ease-out', opacity: anyLit && !lit ? 0.45 : 1 }} />);


          })}
        </svg>

        <div className="absolute left-1/2 top-1/2 flex h-32 w-32 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full bg-navy text-center text-white shadow-lift ring-8 ring-navy-50 sm:h-40 sm:w-40">
          <motion.span
            key={showExample ? 'example' : 'default'}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="px-3 font-heading text-sm font-semibold leading-tight tracking-wide sm:text-base">
            
            {showExample ? '[Program OSIS]' : 'PROGRAM OSIS'}
          </motion.span>
          <span className="mt-1 px-4 text-[11px] leading-tight text-navy-100 sm:text-xs">
            {showExample ? '3 SDGs terhubung' : 'Pusat pemetaan'}
          </span>
        </div>

        {nodes.map((node) => {
          const sdg = getSdg(node.number);
          const lit = isLit(node.number);
          return (
            <button
              key={node.number}
              type="button"
              onClick={() => onSelect(node.number)}
              onMouseEnter={() => setHovered(node.number)}
              onMouseLeave={() => setHovered(null)}
              onFocus={() => setHovered(node.number)}
              onBlur={() => setHovered(null)}
              className="group absolute flex w-24 -translate-x-1/2 -translate-y-1/2 flex-col items-center text-center focus-visible:outline-none sm:w-40"
              style={{ left: `${node.x}%`, top: `${node.y}%` }}
              aria-label={`SDG ${sdg.number}: ${sdg.name}. Buka detail.`}>
              
              <span
                className={`relative block h-14 w-14 overflow-hidden rounded-2xl border-[3px] bg-white shadow-soft transition-transform duration-200 ease-out group-hover:scale-105 group-focus-visible:ring-2 group-focus-visible:ring-navy group-focus-visible:ring-offset-2 sm:h-16 sm:w-16 ${
                lit ? 'scale-105' : ''}`
                }
                style={{ borderColor: sdg.color }}>
                
                <img src={sdg.image} alt="" className="h-full w-full object-cover" />
                <span
                  className="absolute bottom-0 right-0 rounded-tl-lg px-1.5 py-0.5 font-heading text-xs font-bold"
                  style={{ backgroundColor: sdg.color, color: sdg.darkText ? '#0E1C31' : '#fff' }}>
                  
                  {sdg.number}
                </span>
              </span>
              <span className="mt-2 text-xs font-semibold text-navy">SDG {sdg.number}</span>
              <span className="hidden text-[13px] leading-tight text-ink-soft sm:block">{sdg.name}</span>
            </button>);

        })}
      </div>

      <div className="mt-6 flex flex-col items-center gap-4 text-center">
        <p className="max-w-xl font-heading text-xl font-semibold text-navy sm:text-2xl">
          “Satu program dapat berkontribusi pada satu atau lebih SDGs.”
        </p>
        <button
          type="button"
          onClick={() => setShowExample((v) => !v)}
          aria-pressed={showExample}
          className={`inline-flex items-center gap-2 whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold transition-[background-color,color] duration-150 ${
          showExample ? 'bg-navy text-white' : 'border border-navy/15 bg-white text-navy hover:bg-navy-50'}`
          }>
          
          {showExample ? 'Sembunyikan contoh' : 'Lihat contoh pemetaan'}
        </button>
      </div>
    </div>);

}