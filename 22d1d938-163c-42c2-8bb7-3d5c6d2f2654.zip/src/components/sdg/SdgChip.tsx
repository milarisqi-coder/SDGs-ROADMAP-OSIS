import React from 'react';
import { getSdg } from '../../utils/sdg';

export function SdgChip({ number }: {number: number;}) {
  const sdg = getSdg(number);
  return (
    <span
      className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border border-line bg-white px-2.5 py-1 text-xs font-semibold text-ink"
      title={sdg.name}>
      
      <span className="h-2 w-2 rounded-full" style={{ backgroundColor: sdg.color }} aria-hidden="true" />
      SDG {number}
    </span>);

}