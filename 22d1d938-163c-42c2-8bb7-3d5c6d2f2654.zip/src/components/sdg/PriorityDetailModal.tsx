import React from 'react';
import { ArrowRightIcon, CheckIcon, PlusIcon } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { SdgTile } from './SdgTile';
import { useLastDefined } from '../../hooks/useLastDefined';
import { useSchoolData } from '../../contexts/SchoolDataContext';
import { useEditMode } from '../../contexts/EditModeContext';
import { useNavigation } from '../../contexts/NavigationContext';
import type { PriorityDetail } from '../../types/content';
import { getSdg, padNumber } from '../../utils/sdg';
import { btnSmall } from '../../utils/styles';

interface PriorityDetailModalProps {
  detail: PriorityDetail | null;
  onClose: () => void;
}

export function PriorityDetailModal({ detail, onClose }: PriorityDetailModalProps) {
  const shown = useLastDefined(detail);
  const { programs } = useSchoolData();
  const { isEditing } = useEditMode();
  const { goTo } = useNavigation();

  const sdg = shown ? getSdg(shown.number) : null;
  const linked = shown ? programs.filter((p) => p.sdgs.includes(shown.number)) : [];
  const emptySlots = Math.max(0, 3 - linked.length);

  const sections = shown ?
  [
  { title: 'Apa Tujuan SDG Ini?', body: shown.goal },
  { title: 'Apa Hubungannya dengan Pelajar?', body: shown.studentLink },
  { title: 'Apa Hubungannya dengan OSIS?', body: shown.osisLink }] :

  [];

  return (
    <Modal open={detail !== null} onClose={onClose} title={sdg ? `SDG ${sdg.number} — ${sdg.name}` : 'Detail SDG'} hideTitle size="lg">
      {shown && sdg &&
      <div>
          <div className="relative aspect-[16/8] w-full bg-beige-50 sm:aspect-[21/8]">
            <img src={sdg.image} alt={`Ilustrasi SDG ${sdg.number}: ${sdg.name}`} className="absolute inset-0 h-full w-full object-cover" />
            <SdgTile sdg={sdg} size="lg" className="absolute bottom-4 left-5 sm:bottom-5 sm:left-8" />
          </div>
          <div className="space-y-7 p-6 sm:p-8">
            <div>
              <p className="text-sm font-semibold text-ink-faint">SDG {padNumber(sdg.number)}</p>
              <h2 className="mt-1 font-heading text-2xl font-semibold text-navy sm:text-3xl">{sdg.name}</h2>
              <p className="mt-1 font-medium text-sage-700">{shown.tagline}</p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              {sections.map((s) =>
            <section key={s.title}>
                  <h3 className="font-heading text-[15px] font-semibold text-navy">{s.title}</h3>
                  <p className="mt-2 text-[15px] leading-relaxed text-ink-soft">{s.body}</p>
                </section>
            )}
            </div>

            <section className="border-t border-line pt-6">
              <h3 className="font-heading text-base font-semibold text-navy">Contoh Bentuk Aksi</h3>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                {shown.actions.map((a) =>
              <li key={a} className="flex items-start gap-3 text-ink-soft">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-sage-100 text-sage-700">
                      <CheckIcon className="h-3 w-3" aria-hidden="true" />
                    </span>
                    {a}
                  </li>
              )}
              </ul>
            </section>

            <section className="rounded-2xl bg-cream p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="font-heading text-base font-semibold text-navy">Program OSIS yang Terhubung</h3>
                {isEditing &&
              <button
                type="button"
                onClick={() => {
                  onClose();
                  goTo('program');
                }}
                className={`${btnSmall} bg-white text-navy ring-1 ring-line hover:bg-navy-50`}>
                
                    <PlusIcon className="h-4 w-4" aria-hidden="true" />
                    Hubungkan program
                  </button>
              }
              </div>
              <ul className="mt-4 grid gap-2 sm:grid-cols-3">
                {linked.map((p) =>
              <li key={p.id} className="rounded-xl border border-line bg-white px-4 py-3 text-sm font-semibold text-navy">
                    {p.name}
                    <span className="mt-0.5 block text-xs font-normal text-ink-faint">{p.status}</span>
                  </li>
              )}
                {Array.from({ length: emptySlots }).map((_, i) =>
              <li key={`slot-${i}`} className="rounded-xl border border-dashed border-navy-200 px-4 py-3 text-sm italic text-ink-faint">
                    [Program OSIS]
                  </li>
              )}
              </ul>
              <button
              type="button"
              onClick={() => {
                onClose();
                goTo('program');
              }}
              className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-navy hover:text-sage-700">
              
                Buka Program Kerja
                <ArrowRightIcon className="h-4 w-4" aria-hidden="true" />
              </button>
            </section>
          </div>
        </div>
      }
    </Modal>);

}