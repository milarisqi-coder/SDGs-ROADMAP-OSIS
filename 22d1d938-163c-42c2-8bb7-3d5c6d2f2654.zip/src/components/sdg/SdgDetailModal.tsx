import React from 'react';
import { CheckIcon, ChevronLeftIcon, ChevronRightIcon, InfoIcon, StarIcon } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { SdgTile } from './SdgTile';
import { useLastDefined } from '../../hooks/useLastDefined';
import type { Sdg } from '../../types/content';
import { btnSmall } from '../../utils/styles';
import { padNumber } from '../../utils/sdg';

interface SdgDetailModalProps {
  sdg: Sdg | null;
  onClose: () => void;
  onStep: (direction: -1 | 1) => void;
}

export function SdgDetailModal({ sdg, onClose, onStep }: SdgDetailModalProps) {
  const shown = useLastDefined(sdg);

  return (
    <Modal
      open={sdg !== null}
      onClose={onClose}
      title={shown ? `SDG ${shown.number} — ${shown.name}` : 'Detail SDG'}
      hideTitle
      size="xl"
      footer={
      shown &&
      <div className="flex items-center justify-between gap-3">
            <button type="button" onClick={() => onStep(-1)} disabled={shown.number === 1} className={`${btnSmall} text-navy hover:bg-navy-50 disabled:opacity-40`}>
              <ChevronLeftIcon className="h-4 w-4" aria-hidden="true" />
              Sebelumnya
            </button>
            <span className="text-sm text-ink-faint">{shown.number} / 17</span>
            <button type="button" onClick={() => onStep(1)} disabled={shown.number === 17} className={`${btnSmall} text-navy hover:bg-navy-50 disabled:opacity-40`}>
              Berikutnya
              <ChevronRightIcon className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>

      }>
      
      {shown &&
      <div className="grid md:grid-cols-[1fr_1.1fr]">
          <div className="relative bg-beige-50">
            <img src={shown.image} alt={`Ilustrasi SDG ${shown.number}: ${shown.name}`} className="h-60 w-full object-cover md:h-full md:min-h-[520px]" />
            <SdgTile sdg={shown} size="lg" className="absolute left-5 top-5" />
          </div>
          <div className="space-y-7 p-6 sm:p-8">
            <div className="pr-10">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-semibold text-ink-faint">SDG {padNumber(shown.number)}</span>
                {shown.priority &&
              <span className="inline-flex items-center gap-1 rounded-full bg-sunny-100 px-2 py-0.5 text-xs font-semibold text-sunny-700">
                    <StarIcon className="h-3 w-3" aria-hidden="true" />
                    Prioritas OSIS
                  </span>
              }
              </div>
              <h2 className="mt-1 font-heading text-2xl font-semibold leading-tight text-navy sm:text-3xl">{shown.name}</h2>
              <p className="mt-3 text-[17px] leading-relaxed text-ink-soft">{shown.short}</p>
            </div>

            <section>
              <h3 className="font-heading text-base font-semibold text-navy">Apa hubungannya dengan pelajar?</h3>
              <p className="mt-2 leading-relaxed text-ink-soft">{shown.studentLink}</p>
            </section>

            <section>
              <h3 className="font-heading text-base font-semibold text-navy">Contoh kontribusi siswa</h3>
              <ul className="mt-3 space-y-2">
                {shown.contributions.map((item) =>
              <li key={item} className="flex items-start gap-3 text-ink-soft">
                    <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-sage-100 text-sage-700">
                      <CheckIcon className="h-3 w-3" aria-hidden="true" />
                    </span>
                    {item}
                  </li>
              )}
              </ul>
            </section>

            <section className="rounded-2xl bg-beige-50 p-5">
              <h3 className="font-heading text-base font-semibold text-navy">Contoh hubungan dengan kegiatan OSIS</h3>
              <p className="mt-2 leading-relaxed text-ink">{shown.osisExample}</p>
              <p className="mt-3 flex items-center gap-1.5 text-[13px] text-ink-faint">
                <InfoIcon className="h-3.5 w-3.5" aria-hidden="true" />
                Contoh umum — bukan program yang sudah berjalan.
              </p>
            </section>
          </div>
        </div>
      }
    </Modal>);

}