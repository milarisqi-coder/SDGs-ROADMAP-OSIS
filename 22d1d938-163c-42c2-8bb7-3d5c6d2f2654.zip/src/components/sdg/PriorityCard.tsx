import React from 'react';
import { ArrowRightIcon } from 'lucide-react';
import { SdgTile } from './SdgTile';
import type { PriorityDetail, Sdg } from '../../types/content';
import { padNumber } from '../../utils/sdg';

interface PriorityCardProps {
  sdg: Sdg;
  detail: PriorityDetail;
  onOpen: () => void;
}

export function PriorityCard({ sdg, detail, onOpen }: PriorityCardProps) {
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-3xl border border-line bg-white shadow-soft transition-[transform,box-shadow] duration-200 ease-out hover:-translate-y-1 hover:shadow-lift">
      <button
        type="button"
        onClick={onOpen}
        className="relative aspect-[16/10] w-full overflow-hidden bg-beige-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-navy"
        aria-label={`Buka detail SDG ${sdg.number}: ${sdg.name}`}>
        
        <img
          src={sdg.image}
          alt=""
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-300 ease-out group-hover:scale-[1.04]" />
        
        <SdgTile sdg={sdg} size="lg" className="absolute left-4 top-4" />
      </button>

      <div className="flex flex-1 flex-col p-6">
        <p className="text-sm font-semibold tracking-wide text-ink-faint">SDG {padNumber(sdg.number)}</p>
        <h3 className="mt-1 font-heading text-xl font-semibold uppercase leading-snug tracking-wide text-navy">{sdg.name}</h3>
        <p className="mt-1 text-sm font-medium text-sage-700">{detail.tagline}</p>
        <p className="mt-3 leading-relaxed text-ink-soft">{sdg.short}</p>

        <div className="mt-5 rounded-2xl bg-cream p-4">
          <p className="text-sm font-semibold text-navy">Bagaimana pelajar dapat berkontribusi?</p>
          <p className="mt-1 text-[15px] leading-relaxed text-ink-soft">{detail.contributionExample}</p>
        </div>

        <button
          type="button"
          onClick={onOpen}
          className="mt-auto inline-flex items-center gap-2 self-start pt-6 text-[15px] font-semibold text-navy transition-colors duration-150 hover:text-sage-700">
          
          Lihat Hubungan dengan OSIS
          <ArrowRightIcon className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5" aria-hidden="true" />
        </button>
      </div>
    </article>);

}