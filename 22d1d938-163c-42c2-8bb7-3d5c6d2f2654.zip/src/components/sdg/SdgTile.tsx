import React from 'react';
import type { Sdg } from '../../types/content';

type TileSize = 'sm' | 'md' | 'lg';

const sizes: Record<TileSize, {box: string;num: string;icon: string;}> = {
  sm: { box: 'h-11 w-11 rounded-lg', num: 'text-[15px]', icon: 'h-3.5 w-3.5' },
  md: { box: 'h-14 w-14 rounded-xl', num: 'text-xl', icon: 'h-4 w-4' },
  lg: { box: 'h-20 w-20 rounded-2xl', num: 'text-3xl', icon: 'h-6 w-6' }
};

interface SdgTileProps {
  sdg: Sdg;
  size?: TileSize;
  className?: string;
}

/** Official-style SDG tile: goal colour, number and pictogram. */
export function SdgTile({ sdg, size = 'md', className = '' }: SdgTileProps) {
  const Icon = sdg.icon;
  const s = sizes[size];
  return (
    <div
      className={`flex shrink-0 flex-col items-center justify-center gap-0.5 shadow-soft ${s.box} ${className}`}
      style={{ backgroundColor: sdg.color, color: sdg.darkText ? '#0E1C31' : '#FFFFFF' }}
      aria-hidden="true">
      
      <span className={`font-heading font-bold leading-none ${s.num}`}>{sdg.number}</span>
      <Icon className={s.icon} strokeWidth={2.4} />
    </div>);

}