import React, { useState } from 'react';
import { ArrowRightIcon, ChevronDownIcon, StarIcon } from 'lucide-react';
import { SdgTile } from './SdgTile';
import type { Sdg } from '../../types/content';
import { iconBtn } from '../../utils/styles';
import { padNumber } from '../../utils/sdg';

interface SdgCardProps {
  sdg: Sdg;
  onOpen: (sdg: Sdg) => void;
}

export function SdgCard({ sdg, onOpen }: SdgCardProps) {
  const [expanded, setExpanded] = useState(false);
  const panelId = `sdg-panel-${sdg.number}`;

  return (
    <article className="group flex overflow-hidden rounded-2xl border border-line bg-white shadow-soft transition-[transform,box-shadow] duration-200 ease-out hover:-translate-y-1 hover:shadow-lift md:flex-col">
      <button
        type="button"
        onClick={() => onOpen(sdg)}
        className="relative min-h-[7rem] w-28 shrink-0 self-stretch overflow-hidden md:min-h-0 bg-beige-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-navy sm:w-36 md:aspect-[16/11] md:w-full"
        aria-label={`Lihat detail SDG ${sdg.number}: ${sdg.name}`}>
        
        <img
          src={sdg.image}
          alt=""
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-300 ease-out group-hover:scale-[1.04]" />
        
        <SdgTile sdg={sdg} size="sm" className="absolute left-2.5 top-2.5 md:left-3 md:top-3 md:h-14 md:w-14 md:rounded-xl" />
      </button>

      <div className="flex min-w-0 flex-1 flex-col p-4 md:p-5">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: sdg.color }} aria-hidden="true" />
              <span className="text-xs font-semibold tracking-wide text-ink-faint">SDG {padNumber(sdg.number)}</span>
              {sdg.priority &&
              <span className="inline-flex items-center gap-1 rounded-full bg-sunny-100 px-2 py-0.5 text-[11px] font-semibold text-sunny-700">
                  <StarIcon className="h-3 w-3" aria-hidden="true" />
                  Prioritas OSIS
                </span>
              }
            </div>
            <h3 className="mt-1.5 font-heading text-[17px] font-semibold leading-snug text-navy">{sdg.name}</h3>
          </div>
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className={`${iconBtn} -mr-1 md:hidden`}
            aria-expanded={expanded}
            aria-controls={panelId}
            aria-label={expanded ? 'Sembunyikan penjelasan' : 'Tampilkan penjelasan'}>
            
            <ChevronDownIcon className={`h-4 w-4 transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`} />
          </button>
        </div>

        <div id={panelId} className={`${expanded ? 'flex' : 'hidden'} flex-1 flex-col md:flex`}>
          <p className="mt-2 text-[15px] leading-relaxed text-ink-soft">{sdg.short}</p>
          <button
            type="button"
            onClick={() => onOpen(sdg)}
            className="mt-auto inline-flex items-center gap-1.5 self-start pt-4 text-sm font-semibold text-navy transition-colors duration-150 hover:text-sage-700">
            
            Lihat Detail
            <ArrowRightIcon className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5" aria-hidden="true" />
          </button>
        </div>
      </div>
    </article>);

}