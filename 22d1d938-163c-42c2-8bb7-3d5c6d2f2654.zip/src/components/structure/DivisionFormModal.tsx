import React, { useEffect, useState } from 'react';
import { Modal } from '../ui/Modal';
import { FormField } from '../ui/FormField';
import { btnPrimary, btnSecondary, inputClass } from '../../utils/styles';

interface DivisionFormModalProps {
  open: boolean;
  initialName: string;
  isNew: boolean;
  onSave: (name: string) => void;
  onClose: () => void;
}

export function DivisionFormModal({ open, initialName, isNew, onSave, onClose }: DivisionFormModalProps) {
  const [name, setName] = useState(initialName);

  useEffect(() => {
    if (open) setName(initialName);
  }, [open, initialName]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave(name.trim());
  };

  return (
    <Modal open={open} onClose={onClose} title={isNew ? 'Tambah Seksi Bidang' : 'Edit Seksi Bidang'} size="md">
      <form onSubmit={submit} className="space-y-5 p-6">
        <FormField label="Nama Seksi/Bidang" htmlFor="division-name" hint="Contoh: Seksi Kesehatan & Lingkungan Hidup">
          <input id="division-name" className={inputClass} value={name} onChange={(e) => setName(e.target.value)} required />
        </FormField>
        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button type="button" onClick={onClose} className={btnSecondary}>
            Cancel
          </button>
          <button type="submit" className={btnPrimary} disabled={!name.trim()}>
            Save Changes
          </button>
        </div>
      </form>
    </Modal>);

}