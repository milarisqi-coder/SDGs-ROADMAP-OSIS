import React, { useEffect, useRef, useState } from 'react';
import { CameraIcon, UserRoundIcon, XIcon } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { FormField } from '../ui/FormField';
import { CORE_DIVISION_ID, type Division, type Member } from '../../types/organization';
import { btnPrimary, btnSecondary, btnSmall, inputClass } from '../../utils/styles';

interface MemberFormModalProps {
  member: Member | null;
  isNew: boolean;
  divisions: Division[];
  onSave: (member: Member) => void;
  onClose: () => void;
}

export function MemberFormModal({ member, isNew, divisions, onSave, onClose }: MemberFormModalProps) {
  const [form, setForm] = useState<Member | null>(member);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (member) setForm(member);
  }, [member]);

  const isCore = form?.divisionId === CORE_DIVISION_ID;
  const update = (patch: Partial<Member>) => setForm((prev) => prev ? { ...prev, ...patch } : prev);

  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => update({ photo: typeof reader.result === 'string' ? reader.result : '' });
    reader.readAsDataURL(file);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form || !form.name.trim() || !form.position.trim()) return;
    onSave({ ...form, name: form.name.trim(), position: form.position.trim() });
  };

  return (
    <Modal open={member !== null} onClose={onClose} title={isNew ? 'Tambah Pengurus' : 'Edit Data Pengurus'} size="md">
      {form &&
      <form onSubmit={submit} className="space-y-5 p-6">
          <div className="flex items-center gap-4">
            {form.photo ?
          <img src={form.photo} alt="Pratinjau foto" className="h-16 w-16 rounded-full object-cover" /> :

          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-beige-100 text-beige-700">
                <UserRoundIcon className="h-7 w-7" aria-hidden="true" />
              </span>
          }
            <div className="flex flex-wrap gap-2">
              <input ref={fileRef} id="member-photo" type="file" accept="image/*" className="sr-only" onChange={handlePhoto} />
              <button type="button" onClick={() => fileRef.current?.click()} className={`${btnSmall} bg-navy-50 text-navy hover:bg-navy-100`}>
                <CameraIcon className="h-4 w-4" aria-hidden="true" />
                {form.photo ? 'Ganti Foto' : 'Unggah Foto'}
              </button>
              {form.photo &&
            <button type="button" onClick={() => update({ photo: '' })} className={`${btnSmall} text-ink-soft hover:bg-cream`}>
                  <XIcon className="h-4 w-4" aria-hidden="true" />
                  Hapus
                </button>
            }
            </div>
          </div>

          <FormField label="Nama" htmlFor="member-name" hint="Tulis nama lengkap pengurus.">
            <input
            id="member-name"
            className={inputClass}
            value={form.name.startsWith('[') ? '' : form.name}
            placeholder={form.name.startsWith('[') ? form.name : 'Nama lengkap'}
            onChange={(e) => update({ name: e.target.value })} />
          
          </FormField>
          <FormField label="Jabatan" htmlFor="member-position">
            <input id="member-position" className={inputClass} value={form.position} onChange={(e) => update({ position: e.target.value })} required />
          </FormField>
          <FormField label="Seksi/Bidang" htmlFor="member-division" hint={isCore ? 'Pengurus inti tidak berada di seksi bidang.' : undefined}>
            <select
            id="member-division"
            className={inputClass}
            value={form.divisionId}
            onChange={(e) => update({ divisionId: e.target.value })}
            disabled={isCore}>
            
              {isCore && <option value={CORE_DIVISION_ID}>Pengurus Inti</option>}
              {divisions.map((d) =>
            <option key={d.id} value={d.id}>
                  {d.name}
                </option>
            )}
            </select>
          </FormField>
          <FormField label="Periode" htmlFor="member-period">
            <input id="member-period" className={inputClass} value={form.period} onChange={(e) => update({ period: e.target.value })} />
          </FormField>

          <div className="flex flex-col-reverse gap-3 pt-2 sm:flex-row sm:justify-end">
            <button type="button" onClick={onClose} className={btnSecondary}>
              Cancel
            </button>
            <button type="submit" className={btnPrimary} disabled={!form.name.trim() || !form.position.trim()}>
              Save Changes
            </button>
          </div>
        </form>
      }
    </Modal>);

}