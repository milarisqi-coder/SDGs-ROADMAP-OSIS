import React from 'react';
import { ChevronDownIcon, ChevronUpIcon, PencilIcon, UserRoundIcon } from 'lucide-react';
import { ConfirmButton } from '../ui/ConfirmButton';
import type { Member } from '../../types/organization';
import { iconBtn } from '../../utils/styles';
import { initials, placeholderClass } from '../../utils/text';

interface MemberCardProps {
  member: Member;
  variant: 'core' | 'compact';
  editing: boolean;
  onEdit: () => void;
  onDelete?: () => void;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  highlight?: boolean;
}

function Avatar({ member, size }: {member: Member;size: 'md' | 'sm';}) {
  const cls = size === 'md' ? 'h-12 w-12 text-base' : 'h-10 w-10 text-sm';
  if (member.photo) {
    return <img src={member.photo} alt={`Foto ${member.name}`} className={`${cls} shrink-0 rounded-full object-cover`} />;
  }
  const letters = initials(member.name);
  return (
    <span className={`${cls} flex shrink-0 items-center justify-center rounded-full bg-beige-100 font-heading font-semibold text-beige-700`} aria-hidden="true">
      {letters || <UserRoundIcon className="h-5 w-5" />}
    </span>);

}

export function MemberCard({ member, variant, editing, onEdit, onDelete, onMoveUp, onMoveDown, highlight }: MemberCardProps) {
  if (variant === 'core') {
    return (
      <div
        className={`flex w-full items-center gap-3 rounded-2xl border p-4 shadow-soft transition-[border-color,box-shadow] duration-200 ease-out sm:w-[290px] ${
        highlight ? 'border-navy bg-navy text-white' : 'border-line bg-white'} ${
        editing ? 'hover:shadow-lift' : ''}`}>
        
        <Avatar member={member} size="md" />
        <div className="min-w-0 flex-1">
          <p className={`text-xs font-semibold uppercase tracking-wide ${highlight ? 'text-sunny' : 'text-sage-700'}`}>{member.position}</p>
          <p className={`mt-0.5 truncate font-heading text-[15px] font-semibold ${highlight ? 'text-white' : 'text-navy'} ${highlight ? '' : placeholderClass(member.name)}`}>
            {member.name}
          </p>
        </div>
        {editing &&
        <button
          type="button"
          onClick={onEdit}
          className={highlight ? `${iconBtn} text-white hover:bg-white/15 hover:text-white` : iconBtn}
          aria-label={`Edit ${member.position}`}>
          
            <PencilIcon className="h-4 w-4" />
          </button>
        }
      </div>);

  }

  return (
    <li className="flex items-center gap-3 rounded-xl px-2 py-2 transition-colors duration-150 hover:bg-cream">
      <Avatar member={member} size="sm" />
      <div className="min-w-0 flex-1">
        <p className={`truncate text-[15px] font-medium text-ink ${placeholderClass(member.name)}`}>{member.name}</p>
        <p className="text-[13px] text-ink-faint">{member.position}</p>
      </div>
      {editing &&
      <div className="flex items-center">
          <button type="button" onClick={onMoveUp} disabled={!onMoveUp} className={iconBtn} aria-label={`Pindahkan ${member.name} ke atas`}>
            <ChevronUpIcon className="h-4 w-4" />
          </button>
          <button type="button" onClick={onMoveDown} disabled={!onMoveDown} className={iconBtn} aria-label={`Pindahkan ${member.name} ke bawah`}>
            <ChevronDownIcon className="h-4 w-4" />
          </button>
          <button type="button" onClick={onEdit} className={iconBtn} aria-label={`Edit ${member.name}`}>
            <PencilIcon className="h-4 w-4" />
          </button>
          {onDelete && <ConfirmButton label={member.name} onConfirm={onDelete} />}
        </div>
      }
    </li>);

}