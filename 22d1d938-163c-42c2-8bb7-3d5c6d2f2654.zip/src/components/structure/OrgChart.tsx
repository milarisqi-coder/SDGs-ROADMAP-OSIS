import React from 'react';
import { PlusIcon } from 'lucide-react';
import { MemberCard } from './MemberCard';
import { DivisionCard } from './DivisionCard';
import { useSchoolData } from '../../contexts/SchoolDataContext';
import type { Division, Member } from '../../types/organization';
import { btnSmall } from '../../utils/styles';

interface OrgChartProps {
  editing: boolean;
  onEditMember: (member: Member) => void;
  onAddMember: (divisionId: string) => void;
  onEditDivision: (division: Division | null) => void;
}

function Connector({ tall = false }: {tall?: boolean;}) {
  return <div className={`mx-auto w-px bg-navy-200 ${tall ? 'h-10' : 'h-7'}`} aria-hidden="true" />;
}

export function OrgChart({ editing, onEditMember, onAddMember, onEditDivision }: OrgChartProps) {
  const { organization } = useSchoolData();
  const { core, divisions } = organization;

  return (
    <div className="flex flex-col items-center">
      <MemberCard member={core.pembina} variant="core" editing={editing} onEdit={() => onEditMember(core.pembina)} />
      <Connector />
      <MemberCard member={core.ketua} variant="core" editing={editing} onEdit={() => onEditMember(core.ketua)} highlight />
      <Connector />
      <MemberCard member={core.wakil} variant="core" editing={editing} onEdit={() => onEditMember(core.wakil)} />
      <Connector />

      <div className="relative grid w-full max-w-[660px] gap-4 sm:grid-cols-2 sm:gap-10">
        <div className="absolute left-1/4 right-1/4 top-0 hidden h-px bg-navy-200 sm:block" aria-hidden="true" />
        {[core.sekretaris, core.bendahara].map((m) =>
        <div key={m.id} className="flex flex-col items-center">
            <div className="hidden h-6 w-px bg-navy-200 sm:block" aria-hidden="true" />
            <MemberCard member={m} variant="core" editing={editing} onEdit={() => onEditMember(m)} />
          </div>
        )}
      </div>

      <Connector tall />
      <div className="flex flex-wrap items-center justify-center gap-3">
        <span className="rounded-full bg-navy-50 px-4 py-2 font-heading text-sm font-semibold tracking-wide text-navy">SEKSI BIDANG / DIVISI</span>
        {editing &&
        <button type="button" onClick={() => onEditDivision(null)} className={`${btnSmall} bg-navy text-white hover:bg-navy-700`}>
            <PlusIcon className="h-4 w-4" aria-hidden="true" />
            Tambah Seksi
          </button>
        }
      </div>

      <div className="mt-8 grid w-full gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {divisions.map((division, i) =>
        <DivisionCard
          key={division.id}
          division={division}
          index={i}
          total={divisions.length}
          editing={editing}
          onEditDivision={onEditDivision}
          onEditMember={onEditMember}
          onAddMember={onAddMember} />

        )}
      </div>
      {divisions.length === 0 &&
      <p className="mt-4 w-full rounded-2xl border border-dashed border-line px-6 py-10 text-center text-ink-faint">
          Belum ada seksi bidang. Aktifkan Edit Mode untuk menambahkan.
        </p>
      }
    </div>);

}