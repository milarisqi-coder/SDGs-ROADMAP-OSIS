import React from 'react';
import { ChevronLeftIcon, ChevronRightIcon, PencilIcon, UserPlusIcon } from 'lucide-react';
import { MemberCard } from './MemberCard';
import { ConfirmButton } from '../ui/ConfirmButton';
import { useSchoolData } from '../../contexts/SchoolDataContext';
import type { Division, Member } from '../../types/organization';
import { btnSmall, iconBtn } from '../../utils/styles';

interface DivisionCardProps {
  division: Division;
  index: number;
  total: number;
  editing: boolean;
  onEditDivision: (division: Division) => void;
  onEditMember: (member: Member) => void;
  onAddMember: (divisionId: string) => void;
}

export function DivisionCard({ division, index, total, editing, onEditDivision, onEditMember, onAddMember }: DivisionCardProps) {
  const { deleteMember, moveMember, deleteDivision, moveDivision } = useSchoolData();

  return (
    <article className="flex h-full flex-col rounded-3xl border border-line bg-white p-5 shadow-soft">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="font-heading text-base font-semibold leading-snug text-navy">{division.name}</h3>
          <p className="mt-0.5 text-[13px] text-ink-faint">{division.members.length} pengurus</p>
        </div>
        {editing &&
        <div className="-mr-1 flex shrink-0 items-center">
            <button type="button" onClick={() => moveDivision(division.id, -1)} disabled={index === 0} className={iconBtn} aria-label="Geser seksi ke kiri">
              <ChevronLeftIcon className="h-4 w-4" />
            </button>
            <button type="button" onClick={() => moveDivision(division.id, 1)} disabled={index === total - 1} className={iconBtn} aria-label="Geser seksi ke kanan">
              <ChevronRightIcon className="h-4 w-4" />
            </button>
            <button type="button" onClick={() => onEditDivision(division)} className={iconBtn} aria-label={`Edit ${division.name}`}>
              <PencilIcon className="h-4 w-4" />
            </button>
            <ConfirmButton label={division.name} onConfirm={() => deleteDivision(division.id)} />
          </div>
        }
      </div>

      {division.members.length > 0 ?
      <ul className="-mx-2 mt-4 space-y-0.5">
          {division.members.map((member, i) =>
        <MemberCard
          key={member.id}
          member={member}
          variant="compact"
          editing={editing}
          onEdit={() => onEditMember(member)}
          onDelete={() => deleteMember(member.id)}
          onMoveUp={i > 0 ? () => moveMember(division.id, member.id, -1) : undefined}
          onMoveDown={i < division.members.length - 1 ? () => moveMember(division.id, member.id, 1) : undefined} />

        )}
        </ul> :

      <p className="mt-4 rounded-xl border border-dashed border-line px-4 py-5 text-center text-sm text-ink-faint">Belum ada pengurus di seksi ini.</p>
      }

      {editing &&
      <div className="mt-auto pt-4">
          <button
          type="button"
          onClick={() => onAddMember(division.id)}
          className={`${btnSmall} bg-sage-100 text-sage-700 hover:bg-sage-200`}>
          
            <UserPlusIcon className="h-4 w-4" aria-hidden="true" />
            Tambah Anggota
          </button>
        </div>
      }
    </article>);

}