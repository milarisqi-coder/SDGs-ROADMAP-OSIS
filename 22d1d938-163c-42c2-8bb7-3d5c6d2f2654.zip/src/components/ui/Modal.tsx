import React, { useEffect, useRef } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { XIcon } from 'lucide-react';
import { iconBtn } from '../../utils/styles';

type ModalSize = 'md' | 'lg' | 'xl';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  hideTitle?: boolean;
  size?: ModalSize;
  children: React.ReactNode;
  footer?: React.ReactNode;
}

const sizeClass: Record<ModalSize, string> = {
  md: 'sm:max-w-lg',
  lg: 'sm:max-w-3xl',
  xl: 'sm:max-w-5xl'
};

export function Modal({ open, onClose, title, hideTitle = false, size = 'lg', children, footer }: ModalProps) {
  const reduce = useReducedMotion();
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeRef.current();
    };
    document.addEventListener('keydown', onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const t = window.setTimeout(() => panelRef.current?.focus(), 10);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevOverflow;
      window.clearTimeout(t);
    };
  }, [open]);

  return (
    <AnimatePresence>
      {open &&
      <div className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center sm:p-6">
          <motion.div
          className="absolute inset-0 bg-navy-900/50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
          aria-hidden="true" />
        
          <motion.div
          ref={panelRef}
          tabIndex={-1}
          role="dialog"
          aria-modal="true"
          aria-label={title}
          className={`relative flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-3xl bg-white shadow-lift outline-none sm:max-h-[88vh] sm:rounded-3xl ${sizeClass[size]}`}
          initial={reduce ? { opacity: 0 } : { opacity: 0, y: 18, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={reduce ? { opacity: 0 } : { opacity: 0, y: 12, scale: 0.98 }}
          transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}>
          
            {hideTitle ?
          <button
            type="button"
            onClick={onClose}
            className={`${iconBtn} absolute right-4 top-4 z-10 h-10 w-10 bg-white/95 shadow-soft`}
            aria-label="Tutup">
            
                <XIcon className="h-5 w-5" />
              </button> :

          <div className="flex items-center justify-between gap-4 border-b border-line px-6 py-4">
                <h2 className="font-heading text-lg font-semibold text-navy">{title}</h2>
                <button type="button" onClick={onClose} className={`${iconBtn} h-10 w-10`} aria-label="Tutup">
                  <XIcon className="h-5 w-5" />
                </button>
              </div>
          }
            <div className="flex-1 overflow-y-auto">{children}</div>
            {footer && <div className="border-t border-line bg-white px-5 py-4 sm:px-6">{footer}</div>}
          </motion.div>
        </div>
      }
    </AnimatePresence>);

}