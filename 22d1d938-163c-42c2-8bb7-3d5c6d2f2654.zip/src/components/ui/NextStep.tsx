import React from 'react';
import { ArrowRightIcon } from 'lucide-react';
import { useNavigation } from '../../contexts/NavigationContext';
import type { TabId } from '../../types/content';
import { container } from '../../utils/styles';

interface NextStepProps {
  to: TabId;
  label: string;
  description: string;
}

export function NextStep({ to, label, description }: NextStepProps) {
  const { goTo } = useNavigation();
  return (
    <section className={`${container} pb-20 pt-6`} aria-label="Lanjutkan perjalanan">
      <button
        type="button"
        onClick={() => goTo(to)}
        className="group flex w-full flex-col gap-5 rounded-3xl border border-line bg-white p-6 text-left shadow-soft transition-[border-color,box-shadow] duration-200 ease-out hover:border-navy/25 hover:shadow-lift focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy sm:flex-row sm:items-center sm:justify-between sm:p-8">
        
        <div>
          <p className="text-sm font-semibold text-sage-700">Lanjutkan perjalanan</p>
          <p className="mt-1 font-heading text-2xl font-semibold text-navy">{label}</p>
          <p className="mt-1 text-ink-soft">{description}</p>
        </div>
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-navy text-white transition-transform duration-200 ease-out group-hover:translate-x-1">
          <ArrowRightIcon className="h-5 w-5" aria-hidden="true" />
        </span>
      </button>
    </section>);

}