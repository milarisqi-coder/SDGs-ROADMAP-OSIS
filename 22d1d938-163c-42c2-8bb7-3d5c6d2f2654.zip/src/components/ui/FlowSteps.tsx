import React from 'react';
import { ArrowRightIcon } from 'lucide-react';
import type { FlowStep } from '../../types/content';

interface FlowStepsProps {
  steps: FlowStep[];
  tone?: 'dark' | 'light';
}

export function FlowSteps({ steps, tone = 'light' }: FlowStepsProps) {
  const dark = tone === 'dark';
  return (
    <ol className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3 lg:flex lg:items-stretch lg:gap-0">
      {steps.map((step, i) => {
        const Icon = step.icon;
        return (
          <li key={step.label} className="flex items-stretch lg:flex-1">
            <div
              className={`flex w-full items-center gap-4 rounded-2xl px-4 py-4 lg:flex-col lg:justify-center lg:gap-3 lg:px-3 lg:py-6 lg:text-center ${
              dark ? 'bg-white/[0.07] ring-1 ring-white/10' : 'bg-white ring-1 ring-line shadow-soft'}`
              }>
              
              <span
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full font-heading text-sm font-semibold ${
                dark ? 'bg-sunny text-navy-900' : 'bg-navy text-white'}`
                }>
                
                {Icon ? <Icon className="h-5 w-5" aria-hidden="true" /> : i + 1}
              </span>
              <div>
                <p className={`font-heading text-base font-semibold tracking-wide ${dark ? 'text-white' : 'text-navy'}`}>
                  {step.label}
                </p>
                {step.caption &&
                <p className={`mt-0.5 text-sm leading-snug ${dark ? 'text-navy-100' : 'text-ink-soft'}`}>{step.caption}</p>
                }
              </div>
            </div>
            {i < steps.length - 1 &&
            <span className="hidden shrink-0 items-center px-1.5 lg:flex" aria-hidden="true">
                <ArrowRightIcon className={`h-5 w-5 ${dark ? 'text-sunny' : 'text-sage-600'}`} />
              </span>
            }
          </li>);

      })}
    </ol>);

}