import React, { useEffect, useState } from 'react';
import { Trash2Icon } from 'lucide-react';
import { iconBtn } from '../../utils/styles';

interface ConfirmButtonProps {
  label: string;
  onConfirm: () => void;
}

export function ConfirmButton({ label, onConfirm }: ConfirmButtonProps) {
  const [armed, setArmed] = useState(false);

  useEffect(() => {
    if (!armed) return;
    const t = window.setTimeout(() => setArmed(false), 3000);
    return () => window.clearTimeout(t);
  }, [armed]);

  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        if (armed) {
          onConfirm();
          setArmed(false);
        } else {
          setArmed(true);
        }
      }}
      aria-label={armed ? `Konfirmasi hapus ${label}` : `Hapus ${label}`}
      className={
      armed ?
      'inline-flex h-8 items-center rounded-full bg-danger-50 px-3 text-xs font-semibold text-danger transition-colors duration-150' :
      `${iconBtn} hover:bg-danger-50 hover:text-danger`
      }>
      
      {armed ? 'Hapus?' : <Trash2Icon className="h-4 w-4" aria-hidden="true" />}
    </button>);

}