import React from 'react';
import type { ProgramStatus } from '../../types/program';

const styles: Record<ProgramStatus, string> = {
  Berjalan: 'bg-muted-100 text-muted-700',
  Selesai: 'bg-sage-100 text-sage-700',
  'Perlu Evaluasi': 'bg-sunny-100 text-sunny-700'
};

export function StatusBadge({ status }: {status: ProgramStatus;}) {
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold ${styles[status]}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />
      {status}
    </span>);

}