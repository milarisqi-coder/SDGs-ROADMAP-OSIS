import React from 'react';
import { motion } from 'framer-motion';
import type { RoadmapStage } from '../../types/content';

interface RoadmapTrackProps {
  stages: RoadmapStage[];
  active: number;
  onSelect: (index: number) => void;
}

export function RoadmapTrack({ stages, active, onSelect }: RoadmapTrackProps) {
  const fill = stages.length > 1 ? active / (stages.length - 1) * 100 : 0;

  return (
    <div className="scrollbar-none -mx-5 overflow-x-auto px-5 sm:-mx-8 sm:px-8 lg:mx-0 lg:overflow-visible lg:px-0">
      <ol className="relative flex min-w-max gap-3 pb-2 lg:grid lg:min-w-0 lg:grid-cols-8 lg:gap-0" aria-label="Delapan tahap roadmap OSIS">
        <li role="presentation" className="absolute left-[6.25%] right-[6.25%] top-7 hidden h-1 rounded-full bg-navy-100 lg:block" aria-hidden="true">
          <motion.div
            className="h-full rounded-full bg-sage-600"
            initial={false}
            animate={{ width: `${fill}%` }}
            transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }} />
          
        </li>
        {stages.map((stage, i) => {
          const Icon = stage.icon;
          const isActive = i === active;
          const done = i < active;
          return (
            <li key={stage.code} className="relative w-[148px] snap-start lg:w-auto">
              <button
                type="button"
                onClick={() => onSelect(i)}
                aria-current={isActive ? 'step' : undefined}
                className={`group flex w-full flex-col items-center rounded-2xl px-2 py-4 text-center transition-[background-color,border-color] duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy lg:border-0 lg:bg-transparent lg:py-0 ${
                isActive ? 'border border-navy bg-white' : 'border border-line bg-white'}`
                }>
                
                <span
                  className={`relative z-10 flex h-14 w-14 items-center justify-center rounded-full border-2 transition-[background-color,border-color,color,transform] duration-200 ease-out ${
                  isActive ?
                  'scale-105 border-navy bg-navy text-white shadow-lift' :
                  done ?
                  'border-sage-600 bg-sage-100 text-sage-700' :
                  'border-navy-100 bg-white text-navy group-hover:border-navy/40'}`
                  }>
                  
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <span className="mt-3 text-xs font-semibold text-ink-faint">{stage.number}</span>
                <span className={`font-heading text-sm font-bold tracking-wide ${isActive ? 'text-navy' : 'text-navy/80'}`}>{stage.code}</span>
                <span className="mt-0.5 text-[13px] leading-snug text-ink-soft">{stage.title}</span>
              </button>
            </li>);

        })}
      </ol>
    </div>);

}