import React from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { CheckIcon, ChevronLeftIcon, ChevronRightIcon, PackageCheckIcon, TargetIcon } from 'lucide-react';
import type { RoadmapStage } from '../../types/content';
import { btnSmall } from '../../utils/styles';

interface RoadmapStageDetailProps {
  stage: RoadmapStage;
  index: number;
  total: number;
  checks: boolean[];
  onToggleCheck: (i: number) => void;
  onStep: (direction: -1 | 1) => void;
}

export function RoadmapStageDetail({ stage, index, total, checks, onToggleCheck, onStep }: RoadmapStageDetailProps) {
  const reduce = useReducedMotion();
  const Icon = stage.icon;
  const doneCount = checks.filter(Boolean).length;

  return (
    <div className="overflow-hidden rounded-[32px] border border-line bg-white shadow-soft">
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={stage.code}
          initial={reduce ? { opacity: 0 } : { opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={reduce ? { opacity: 0 } : { opacity: 0, y: -6 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          className="grid lg:grid-cols-[1.35fr_1fr]">
          
          <div className="p-6 sm:p-10">
            <div className="flex items-center gap-4">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-navy text-white">
                <Icon className="h-6 w-6" aria-hidden="true" />
              </span>
              <div>
                <p className="font-heading text-sm font-bold tracking-[0.14em] text-sage-700">
                  {stage.number} — {stage.code}
                </p>
                <h2 className="font-heading text-2xl font-semibold text-navy sm:text-3xl">{stage.title}</h2>
              </div>
            </div>
            <p className="mt-6 text-lg leading-relaxed text-ink-soft">{stage.explanation}</p>

            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              <section>
                <h3 className="flex items-center gap-2 font-heading text-[15px] font-semibold text-navy">
                  <TargetIcon className="h-4 w-4 text-sage-700" aria-hidden="true" />
                  Tujuan
                </h3>
                <p className="mt-2 leading-relaxed text-ink-soft">{stage.goal}</p>
              </section>
              <section>
                <h3 className="flex items-center gap-2 font-heading text-[15px] font-semibold text-navy">
                  <PackageCheckIcon className="h-4 w-4 text-sage-700" aria-hidden="true" />
                  Output yang dihasilkan
                </h3>
                <p className="mt-2 leading-relaxed text-ink-soft">{stage.output}</p>
              </section>
            </div>

            <section className="mt-8">
              <h3 className="font-heading text-[15px] font-semibold text-navy">Apa yang dilakukan</h3>
              <ol className="mt-3 space-y-2.5">
                {stage.activities.map((a, i) =>
                <li key={a} className="flex items-start gap-3 text-ink-soft">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-navy-50 text-xs font-semibold text-navy">{i + 1}</span>
                    {a}
                  </li>
                )}
              </ol>
            </section>
          </div>

          <div className="flex flex-col gap-6 border-t border-line bg-cream p-6 sm:p-10 lg:border-l lg:border-t-0">
            <section className="rounded-2xl bg-white p-5 ring-1 ring-line">
              <h3 className="font-heading text-[15px] font-semibold text-navy">Contoh aktivitas</h3>
              <p className="mt-2 leading-relaxed text-ink-soft">{stage.example}</p>
            </section>

            <section>
              <div className="flex items-center justify-between">
                <h3 className="font-heading text-[15px] font-semibold text-navy">Checklist sederhana</h3>
                <span className="text-sm text-ink-faint">
                  {doneCount}/{stage.checklist.length}
                </span>
              </div>
              <ul className="mt-3 space-y-2">
                {stage.checklist.map((item, i) => {
                  const checked = checks[i] ?? false;
                  return (
                    <li key={item}>
                      <label className="flex cursor-pointer items-start gap-3 rounded-xl bg-white px-4 py-3 ring-1 ring-line transition-[box-shadow] duration-150 hover:ring-navy/25">
                        <input type="checkbox" className="sr-only" checked={checked} onChange={() => onToggleCheck(i)} />
                        <span
                          className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 transition-[background-color,border-color] duration-150 ${
                          checked ? 'border-sage-700 bg-sage-700 text-white' : 'border-navy-200 bg-white'}`
                          }
                          aria-hidden="true">
                          
                          {checked && <CheckIcon className="h-3 w-3" strokeWidth={3} />}
                        </span>
                        <span className={`text-[15px] ${checked ? 'text-ink-faint line-through' : 'text-ink'}`}>{item}</span>
                      </label>
                    </li>);

                })}
              </ul>
            </section>

            <div className="mt-auto flex items-center justify-between gap-3 pt-2">
              <button type="button" onClick={() => onStep(-1)} disabled={index === 0} className={`${btnSmall} text-navy hover:bg-white disabled:opacity-40`}>
                <ChevronLeftIcon className="h-4 w-4" aria-hidden="true" />
                Sebelumnya
              </button>
              <button type="button" onClick={() => onStep(1)} disabled={index === total - 1} className={`${btnSmall} bg-navy text-white hover:bg-navy-700 disabled:opacity-40`}>
                Tahap berikutnya
                <ChevronRightIcon className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>);

}