import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { TrendingUpIcon } from 'lucide-react';
import { SdgTile } from '../sdg/SdgTile';
import { SdgChip } from '../sdg/SdgChip';
import { StatusBadge } from '../ui/StatusBadge';
import { siteImages } from '../../data/images';
import { getSdg, PRIORITY_NUMBERS } from '../../utils/sdg';
export function HeroVisual() {
  const reduce = useReducedMotion();
  const enter = (delay: number) => ({
    initial: reduce ? false : {
      opacity: 0,
      y: 10
    },
    animate: {
      opacity: 1,
      y: 0
    },
    transition: {
      duration: 0.3,
      ease: [0.23, 1, 0.32, 1],
      delay
    }
  });
  return <div className="relative mx-auto w-full max-w-xl pb-8 pt-6 lg:max-w-none">
      <div className="overflow-hidden rounded-[28px] border border-line bg-white shadow-lift">
        <img src={siteImages.hero} alt="Ilustrasi siswa SMP berseragam putih biru berkolaborasi menyusun roadmap program OSIS" className="aspect-[4/3] w-full object-cover" />
      </div>

      <motion.div {...enter(0.1)} className="absolute right-3 top-0 flex -space-x-2 sm:right-6" aria-hidden="true">
        {PRIORITY_NUMBERS.map((n) => <SdgTile key={n} sdg={getSdg(n)} size="sm" className="ring-2 ring-white" />)}
      </motion.div>

      

      <motion.div {...enter(0.26)} className="absolute -bottom-1 right-2 w-[244px] rounded-2xl bg-navy p-4 text-white shadow-lift sm:right-0 lg:-right-6">
        <div className="flex items-center justify-between text-xs text-navy-100">
          <span>Roadmap OSIS</span>
          <span>Terdiri dari 8 tahap</span>
        </div>
        <p className="mt-1 font-heading text-[15px] font-semibold">Adiwiyata x SDGs</p>
        <div className="mt-3 flex items-center gap-1" aria-hidden="true">
          {Array.from({
          length: 8
        }).map((_, i) => <span key={i} className={`h-1.5 flex-1 rounded-full ${i < 5 ? 'bg-sunny' : 'bg-white/20'}`} />)}
        </div>
        <p className="mt-3 flex items-center gap-1.5 text-xs text-navy-100">
          <TrendingUpIcon className="h-3.5 w-3.5 text-sunny" aria-hidden="true" />
          Tumbuh di setiap tahap
        </p>
      </motion.div>
    </div>;
}