import React from 'react';
import { ArrowRightIcon, CheckIcon, ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { useSchoolData } from '../../contexts/SchoolDataContext';
import { useNavigation } from '../../contexts/NavigationContext';
import { navTabs } from '../../data/navigation';
import { btnSmall, inputClass } from '../../utils/styles';

interface HandbookReaderModalProps {
  chapterId: string | null;
  onChange: (chapterId: string) => void;
  onClose: () => void;
}

export function HandbookReaderModal({ chapterId, onChange, onClose }: HandbookReaderModalProps) {
  const { chapters } = useSchoolData();
  const { goTo } = useNavigation();
  const index = Math.max(0, chapters.findIndex((c) => c.id === chapterId));
  const chapter = chapters[index];
  const related = navTabs.find((t) => t.id === chapter?.relatedTab);

  return (
    <Modal open={chapterId !== null} onClose={onClose} title="SDGs Handbook OSIS" size="xl">
      {chapter &&
      <div className="grid md:grid-cols-[260px_1fr]">
          <nav aria-label="Daftar bab" className="border-b border-line bg-cream p-4 md:border-b-0 md:border-r">
            <label htmlFor="reader-select" className="sr-only">
              Pilih bab
            </label>
            <select id="reader-select" className={`${inputClass} md:hidden`} value={chapter.id} onChange={(e) => onChange(e.target.value)}>
              {chapters.map((c) =>
            <option key={c.id} value={c.id}>
                  Bab {c.bab} — {c.title}
                </option>
            )}
            </select>
            <ul className="hidden space-y-1 md:block">
              {chapters.map((c) =>
            <li key={c.id}>
                  <button
                type="button"
                onClick={() => onChange(c.id)}
                aria-current={c.id === chapter.id ? 'true' : undefined}
                className={`w-full rounded-xl px-3 py-2.5 text-left text-sm transition-colors duration-150 ${
                c.id === chapter.id ? 'bg-navy text-white' : 'text-ink-soft hover:bg-white'}`
                }>
                
                    <span className={`block text-[11px] font-bold tracking-[0.12em] ${c.id === chapter.id ? 'text-sunny' : 'text-sage-700'}`}>BAB {c.bab}</span>
                    <span className="block font-medium">{c.title}</span>
                  </button>
                </li>
            )}
            </ul>
          </nav>

          <article className="flex flex-col p-6 sm:p-10">
            <p className="font-heading text-sm font-bold tracking-[0.14em] text-sage-700">BAB {chapter.bab}</p>
            <h2 className="mt-2 font-heading text-3xl font-semibold leading-tight text-navy">{chapter.title}</h2>
            <p className="mt-4 text-lg leading-relaxed text-ink-soft">{chapter.summary}</p>

            <h3 className="mt-8 font-heading text-base font-semibold text-navy">Yang dibahas di bab ini</h3>
            <ul className="mt-3 space-y-2.5">
              {chapter.points.map((p) =>
            <li key={p} className="flex items-start gap-3 text-ink-soft">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-sage-100 text-sage-700">
                    <CheckIcon className="h-3 w-3" aria-hidden="true" />
                  </span>
                  {p}
                </li>
            )}
            </ul>

            {related &&
          <button
            type="button"
            onClick={() => {
              onClose();
              goTo(related.id);
            }}
            className="mt-8 inline-flex items-center gap-2 self-start rounded-2xl bg-beige-50 px-5 py-4 text-left text-[15px] font-semibold text-navy transition-colors duration-150 hover:bg-beige-100">
            
                Pelajari lebih lanjut di halaman “{related.label}”
                <ArrowRightIcon className="h-4 w-4 shrink-0" aria-hidden="true" />
              </button>
          }

            <div className="mt-auto flex items-center justify-between gap-3 pt-10">
              <button
              type="button"
              onClick={() => onChange(chapters[index - 1].id)}
              disabled={index === 0}
              className={`${btnSmall} text-navy hover:bg-navy-50 disabled:opacity-40`}>
              
                <ChevronLeftIcon className="h-4 w-4" aria-hidden="true" />
                Bab sebelumnya
              </button>
              <button
              type="button"
              onClick={() => onChange(chapters[index + 1].id)}
              disabled={index === chapters.length - 1}
              className={`${btnSmall} bg-navy text-white hover:bg-navy-700 disabled:opacity-40`}>
              
                Bab berikutnya
                <ChevronRightIcon className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          </article>
        </div>
      }
    </Modal>);

}