import React, { useState } from 'react';
import { FileTextIcon, PlusIcon } from 'lucide-react';
import { toast } from 'sonner';
import { ConfirmButton } from '../ui/ConfirmButton';
import { useSchoolData } from '../../contexts/SchoolDataContext';
import { btnSmall, inputClass } from '../../utils/styles';
import { placeholderClass } from '../../utils/text';

export function HandbookResources({ editing }: {editing: boolean;}) {
  const { resources, addResource, removeResource } = useSchoolData();
  const [title, setTitle] = useState('');

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    addResource(title.trim(), 'Sumber tambahan dari pengurus.');
    setTitle('');
    toast.success('Sumber tambahan ditambahkan.');
  };

  return (
    <section aria-labelledby="resources-title">
      <h2 id="resources-title" className="font-heading text-xl font-semibold text-navy">
        Sumber Tambahan
      </h2>
      <p className="mt-1 text-ink-soft">Template dan dokumen pendukung yang dapat digunakan setiap periode.</p>
      <ul className="mt-5 grid gap-3 sm:grid-cols-2">
        {resources.map((r) =>
        <li key={r.id} className="flex items-center gap-3 rounded-2xl border border-line bg-white px-4 py-3.5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-muted-100 text-muted-700">
              <FileTextIcon className="h-5 w-5" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <p className={`truncate font-medium text-ink ${placeholderClass(r.title)}`}>{r.title}</p>
              <p className="truncate text-[13px] text-ink-faint">{r.note}</p>
            </div>
            {editing && <ConfirmButton label={r.title} onConfirm={() => removeResource(r.id)} />}
          </li>
        )}
        {resources.length === 0 && <li className="text-ink-faint">Belum ada sumber tambahan.</li>}
      </ul>
      {editing &&
      <form onSubmit={submit} className="mt-4 flex flex-col gap-2 sm:flex-row">
          <label htmlFor="resource-title" className="sr-only">
            Judul sumber baru
          </label>
          <input
          id="resource-title"
          className={inputClass}
          placeholder="Judul dokumen, contoh: Template Laporan Kegiatan"
          value={title}
          onChange={(e) => setTitle(e.target.value)} />
        
          <button type="submit" className={`${btnSmall} bg-navy px-5 text-white hover:bg-navy-700`} disabled={!title.trim()}>
            <PlusIcon className="h-4 w-4" aria-hidden="true" />
            Tambah
          </button>
        </form>
      }
    </section>);

}