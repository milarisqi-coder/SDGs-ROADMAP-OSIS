import React, { useState } from 'react';
import { ChevronRightIcon, PencilIcon } from 'lucide-react';
import { toast } from 'sonner';
import { useSchoolData } from '../../contexts/SchoolDataContext';
import { btnSmall, iconBtn, inputClass } from '../../utils/styles';

interface HandbookTocProps {
  editing: boolean;
  onOpenChapter: (chapterId: string) => void;
}

export function HandbookToc({ editing, onOpenChapter }: HandbookTocProps) {
  const { chapters, updateChapter } = useSchoolData();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState({ title: '', summary: '' });

  const startEdit = (id: string) => {
    const chapter = chapters.find((c) => c.id === id);
    if (!chapter) return;
    setDraft({ title: chapter.title, summary: chapter.summary });
    setEditingId(id);
  };

  const save = () => {
    if (!editingId || !draft.title.trim()) return;
    updateChapter(editingId, { title: draft.title.trim(), summary: draft.summary.trim() });
    setEditingId(null);
    toast.success('Isi bab diperbarui.');
  };

  return (
    <ol className="divide-y divide-line rounded-3xl border border-line bg-white">
      {chapters.map((chapter) =>
      <li key={chapter.id}>
          {editingId === chapter.id ?
        <div className="space-y-3 p-5">
              <p className="font-heading text-xs font-bold tracking-[0.12em] text-sage-700">BAB {chapter.bab}</p>
              <label htmlFor={`toc-title-${chapter.id}`} className="sr-only">
                Judul bab
              </label>
              <input id={`toc-title-${chapter.id}`} className={inputClass} value={draft.title} onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))} />
              <label htmlFor={`toc-summary-${chapter.id}`} className="sr-only">
                Ringkasan bab
              </label>
              <textarea
            id={`toc-summary-${chapter.id}`}
            rows={2}
            className={`${inputClass} resize-y`}
            value={draft.summary}
            onChange={(e) => setDraft((d) => ({ ...d, summary: e.target.value }))} />
          
              <div className="flex gap-2">
                <button type="button" onClick={save} className={`${btnSmall} bg-navy text-white hover:bg-navy-700`}>
                  Save
                </button>
                <button type="button" onClick={() => setEditingId(null)} className={`${btnSmall} text-ink-soft hover:bg-cream`}>
                  Cancel
                </button>
              </div>
            </div> :

        <div className="group flex items-center gap-4 px-5 py-4 transition-colors duration-150 hover:bg-cream">
              <span className="w-14 shrink-0 font-heading text-xs font-bold tracking-[0.12em] text-sage-700">BAB {chapter.bab}</span>
              <button type="button" onClick={() => onOpenChapter(chapter.id)} className="min-w-0 flex-1 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy">
                <span className="block font-heading text-[15px] font-semibold text-navy">{chapter.title}</span>
                <span className="mt-0.5 block text-sm text-ink-faint">{chapter.summary}</span>
              </button>
              {editing ?
          <button type="button" onClick={() => startEdit(chapter.id)} className={iconBtn} aria-label={`Edit Bab ${chapter.bab}`}>
                  <PencilIcon className="h-4 w-4" />
                </button> :

          <ChevronRightIcon className="h-4 w-4 shrink-0 text-ink-faint transition-transform duration-200 group-hover:translate-x-0.5" aria-hidden="true" />
          }
            </div>
        }
        </li>
      )}
    </ol>);

}