import React from 'react';
import { SproutIcon } from 'lucide-react';
import { sdgs } from '../../data/sdgs';

export function HandbookBook({ period }: {period: string;}) {
  return (
    <div className="group relative mx-auto w-full max-w-[360px] [perspective:1200px]">
      <div className="absolute inset-0 translate-x-3 translate-y-3 rounded-r-[22px] rounded-l-md border border-line bg-beige" aria-hidden="true" />
      <div className="absolute inset-0 translate-x-1.5 translate-y-1.5 rounded-r-[22px] rounded-l-md border border-line bg-beige-50" aria-hidden="true" />
      <div className="relative flex aspect-[3/4] flex-col overflow-hidden rounded-r-[22px] rounded-l-md bg-navy p-8 text-white shadow-lift transition-transform duration-300 ease-out group-hover:-translate-y-1 group-hover:[transform:rotateY(-4deg)]">
        <div className="absolute inset-y-0 left-0 w-3 bg-navy-900/50" aria-hidden="true" />
        <div className="flex items-center gap-2 pl-2 text-xs font-medium text-navy-100">
          <SproutIcon className="h-4 w-4 text-sunny" aria-hidden="true" />
          OSIS · SMP Negeri 37 Surabaya
        </div>

        <div className="mt-auto pl-2">
          <p className="font-heading text-[2.4rem] font-bold leading-[1.02] tracking-tight">
            SDGs
            <br />
            HANDBOOK
          </p>
          <p className="mt-3 text-[15px] leading-snug text-navy-100">Panduan Program OSIS Berbasis SDGs</p>
        </div>

        <div className="mt-8 grid grid-cols-9 gap-1 pl-2" aria-hidden="true">
          {sdgs.map((s) =>
          <span key={s.number} className="aspect-square rounded-[3px]" style={{ backgroundColor: s.color }} />
          )}
          <span className="aspect-square rounded-[3px] bg-white/15" />
        </div>
        <p className="mt-5 pl-2 text-xs text-navy-100">Edisi Periode {period}</p>
      </div>
    </div>);

}