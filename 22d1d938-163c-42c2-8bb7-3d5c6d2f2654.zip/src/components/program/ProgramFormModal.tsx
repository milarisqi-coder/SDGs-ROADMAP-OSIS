import React, { useEffect, useState } from 'react';
import { Modal } from '../ui/Modal';
import { FormField } from '../ui/FormField';
import { useSchoolData } from '../../contexts/SchoolDataContext';
import type { Program, ProgramStatus } from '../../types/program';
import { getSdg, PRIORITY_NUMBERS } from '../../utils/sdg';
import { btnPrimary, btnSecondary, inputClass } from '../../utils/styles';

interface ProgramFormModalProps {
  program: Program | null;
  isNew: boolean;
  onSave: (program: Program) => void;
  onClose: () => void;
}

const statuses: ProgramStatus[] = ['Berjalan', 'Selesai', 'Perlu Evaluasi'];
const otherSdgs = Array.from({ length: 17 }, (_, i) => i + 1).filter((n) => !PRIORITY_NUMBERS.includes(n));

function clean(value: string) {
  return value.trim().startsWith('[') ? '' : value;
}

function toLines(value: string): string[] {
  return value.
  split('\n').
  map((l) => l.trim()).
  filter(Boolean);
}

export function ProgramFormModal({ program, isNew, onSave, onClose }: ProgramFormModalProps) {
  const { organization } = useSchoolData();
  const [form, setForm] = useState<Program | null>(program);
  const [indicatorText, setIndicatorText] = useState('');
  const [docText, setDocText] = useState('');
  const [showOthers, setShowOthers] = useState(false);

  useEffect(() => {
    if (!program) return;
    setForm(program);
    setIndicatorText(program.indicators.filter((i) => !i.startsWith('[')).join('\n'));
    setDocText(program.documentation.filter((i) => !i.startsWith('[')).join('\n'));
    setShowOthers(program.sdgs.some((n) => !PRIORITY_NUMBERS.includes(n)));
  }, [program]);

  const update = (patch: Partial<Program>) => setForm((prev) => prev ? { ...prev, ...patch } : prev);

  const toggleSdg = (n: number) => {
    if (!form) return;
    update({ sdgs: form.sdgs.includes(n) ? form.sdgs.filter((x) => x !== n) : [...form.sdgs, n].sort((a, b) => a - b) });
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form || !form.name.trim()) return;
    onSave({
      ...form,
      name: form.name.trim(),
      indicators: toLines(indicatorText).length ? toLines(indicatorText) : program?.indicators ?? [],
      documentation: toLines(docText).length ? toLines(docText) : program?.documentation ?? []
    });
  };

  const textField = (key: keyof Program, label: string, hint: string, rows = 2) => {
    if (!form) return null;
    const raw = form[key];
    const value = typeof raw === 'string' ? raw : '';
    return (
      <FormField label={label} htmlFor={`pf-${key}`} hint={hint}>
        <textarea
          id={`pf-${key}`}
          rows={rows}
          className={`${inputClass} resize-y`}
          value={clean(value)}
          placeholder={value.startsWith('[') ? value.replace(/^\[|\]$/g, '') : ''}
          onChange={(e) => update({ [key]: e.target.value } as Partial<Program>)} />
        
      </FormField>);

  };

  const sdgToggle = (n: number) => {
    const sdg = getSdg(n);
    const active = form?.sdgs.includes(n) ?? false;
    return (
      <button
        key={n}
        type="button"
        onClick={() => toggleSdg(n)}
        aria-pressed={active}
        className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-medium transition-[background-color,border-color,color] duration-150 ${
        active ? 'border-navy bg-navy text-white' : 'border-line bg-white text-ink hover:border-navy/30'}`
        }>
        
        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: sdg.color }} aria-hidden="true" />
        SDG {n}
      </button>);

  };

  return (
    <Modal open={program !== null} onClose={onClose} title={isNew ? 'Tambah Program Kerja' : 'Edit Program'} size="lg">
      {form &&
      <form onSubmit={submit}>
          <div className="space-y-10 p-6 sm:p-8">
            <fieldset className="space-y-5">
              <legend className="font-heading text-lg font-semibold text-navy">Informasi Dasar</legend>
              <FormField label="Nama Program" htmlFor="pf-name">
                <input id="pf-name" className={inputClass} value={form.name} onChange={(e) => update({ name: e.target.value })} required />
              </FormField>
              <div className="grid gap-5 sm:grid-cols-2">
                <FormField label="Bidang/Seksi" htmlFor="pf-division">
                  <select id="pf-division" className={inputClass} value={form.division} onChange={(e) => update({ division: e.target.value })}>
                    <option value="">Pilih seksi</option>
                    {organization.divisions.map((d) =>
                  <option key={d.id} value={d.name}>
                        {d.name}
                      </option>
                  )}
                  </select>
                </FormField>
                <FormField label="Tahun" htmlFor="pf-year">
                  <input id="pf-year" className={inputClass} value={form.year} onChange={(e) => update({ year: e.target.value })} />
                </FormField>
              </div>
              {textField('summary', 'Deskripsi Singkat', 'Jelaskan program dalam 1–2 kalimat.', 3)}
              <div>
                <p className="text-sm font-semibold text-ink">SDGs Terkait</p>
                <p className="mt-0.5 text-[13px] text-ink-faint">Pilih satu atau lebih. Enam prioritas OSIS ditampilkan lebih dulu.</p>
                <div className="mt-3 flex flex-wrap gap-2">{PRIORITY_NUMBERS.map(sdgToggle)}</div>
                {showOthers ?
              <div className="mt-2 flex flex-wrap gap-2">{otherSdgs.map(sdgToggle)}</div> :

              <button type="button" onClick={() => setShowOthers(true)} className="mt-3 text-sm font-semibold text-navy hover:text-sage-700">
                    + Tampilkan SDG lainnya
                  </button>
              }
              </div>
            </fieldset>

            <fieldset className="space-y-5">
              <legend className="font-heading text-lg font-semibold text-navy">Perencanaan</legend>
              {textField('background', 'Latar Belakang', 'Masalah apa yang ingin diselesaikan?')}
              {textField('goal', 'Tujuan', 'Apa yang ingin dicapai?')}
              {textField('target', 'Sasaran', 'Siapa yang menjadi sasaran program?', 1)}
              <FormField label="Indikator Keberhasilan" htmlFor="pf-indicators" hint="Satu indikator per baris.">
                <textarea id="pf-indicators" rows={3} className={`${inputClass} resize-y`} value={indicatorText} onChange={(e) => setIndicatorText(e.target.value)} />
              </FormField>
            </fieldset>

            <fieldset className="space-y-5">
              <legend className="font-heading text-lg font-semibold text-navy">Pelaksanaan</legend>
              <div className="grid gap-5 sm:grid-cols-2">
                {textField('pic', 'Penanggung Jawab', 'Nama ketua pelaksana.', 1)}
                {textField('period', 'Periode Pelaksanaan', 'Contoh: Agustus – Oktober.', 1)}
              </div>
              <div className="grid gap-5 sm:grid-cols-2">
                <FormField label="Status" htmlFor="pf-status">
                  <select id="pf-status" className={inputClass} value={form.status} onChange={(e) => update({ status: e.target.value as ProgramStatus })}>
                    {statuses.map((s) =>
                  <option key={s} value={s}>
                        {s}
                      </option>
                  )}
                  </select>
                </FormField>
                <FormField label={`Progress: ${form.progress}%`} htmlFor="pf-progress">
                  <input
                  id="pf-progress"
                  type="range"
                  min={0}
                  max={100}
                  step={5}
                  value={form.progress}
                  onChange={(e) => update({ progress: Number(e.target.value) })}
                  className="mt-3 w-full accent-navy" />
                
                </FormField>
              </div>
              <FormField label="Dokumentasi" htmlFor="pf-docs" hint="Tautan foto, laporan, atau catatan. Satu per baris.">
                <textarea id="pf-docs" rows={3} className={`${inputClass} resize-y`} value={docText} onChange={(e) => setDocText(e.target.value)} />
              </FormField>
            </fieldset>

            <fieldset className="space-y-5">
              <legend className="font-heading text-lg font-semibold text-navy">Evaluasi & Refleksi</legend>
              {textField('evaluation', 'Evaluasi', 'Apa yang berjalan baik dan apa yang perlu diperbaiki?')}
              <div className="grid gap-5 sm:grid-cols-2">
                {textField('obstacles', 'Hambatan', 'Kendala yang dihadapi.')}
                {textField('solutions', 'Solusi', 'Cara mengatasinya.')}
              </div>
              {textField('lessons', 'Lessons Learned', 'Pesan penting untuk pengurus berikutnya.', 3)}
              {textField('development', 'Rencana Pengembangan', 'Ide untuk periode berikutnya.')}
            </fieldset>
          </div>

          <div className="sticky bottom-0 flex flex-col-reverse gap-3 border-t border-line bg-white px-6 py-4 sm:flex-row sm:justify-end sm:px-8">
            <button type="button" onClick={onClose} className={btnSecondary}>
              Cancel
            </button>
            <button type="submit" className={btnPrimary} disabled={!form.name.trim()}>
              Save Changes
            </button>
          </div>
        </form>
      }
    </Modal>);

}