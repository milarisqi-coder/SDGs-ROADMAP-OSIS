import React, { useEffect, useState } from 'react';
import { FileTextIcon, LightbulbIcon, LockIcon, PencilIcon } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { StatusBadge } from '../ui/StatusBadge';
import { SdgTile } from '../sdg/SdgTile';
import { useLastDefined } from '../../hooks/useLastDefined';
import { useEditMode } from '../../contexts/EditModeContext';
import type { Program } from '../../types/program';
import { getSdg } from '../../utils/sdg';
import { btnPrimary, btnSecondary } from '../../utils/styles';
import { placeholderClass } from '../../utils/text';

type DetailTab = 'ringkasan' | 'perencanaan' | 'pelaksanaan' | 'refleksi';

const tabs: {id: DetailTab;label: string;}[] = [
{ id: 'ringkasan', label: 'Ringkasan' },
{ id: 'perencanaan', label: 'Perencanaan' },
{ id: 'pelaksanaan', label: 'Pelaksanaan' },
{ id: 'refleksi', label: 'Evaluasi & Refleksi' }];


interface ProgramDetailModalProps {
  program: Program | null;
  onClose: () => void;
  onEdit: (program: Program) => void;
}

function TextBlock({ title, value, emphasis = false }: {title: string;value: string;emphasis?: boolean;}) {
  const text = value || '[Belum diisi]';
  return (
    <section className={emphasis ? 'rounded-2xl bg-sunny-50 p-5 ring-1 ring-sunny-100' : ''}>
      <h4 className="flex items-center gap-2 font-heading text-[15px] font-semibold text-navy">
        {emphasis && <LightbulbIcon className="h-4 w-4 text-sunny-700" aria-hidden="true" />}
        {title}
      </h4>
      <p className={`mt-1.5 leading-relaxed text-ink-soft ${placeholderClass(text)}`}>{text}</p>
    </section>);

}

function ListBlock({ title, items, icon = false }: {title: string;items: string[];icon?: boolean;}) {
  return (
    <section>
      <h4 className="font-heading text-[15px] font-semibold text-navy">{title}</h4>
      {items.length ?
      <ul className="mt-2 space-y-2">
          {items.map((item) =>
        <li key={item} className={`flex items-start gap-2.5 text-ink-soft ${placeholderClass(item)}`}>
              {icon ?
          <FileTextIcon className="mt-0.5 h-4 w-4 shrink-0 text-muted-700" aria-hidden="true" /> :

          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-sage-600" aria-hidden="true" />
          }
              {item}
            </li>
        )}
        </ul> :

      <p className="mt-1.5 italic text-ink-faint">[Belum diisi]</p>
      }
    </section>);

}

export function ProgramDetailModal({ program, onClose, onEdit }: ProgramDetailModalProps) {
  const shown = useLastDefined(program);
  const { isEditing, requestEditMode } = useEditMode();
  const [tab, setTab] = useState<DetailTab>('ringkasan');

  useEffect(() => {
    if (program) setTab('ringkasan');
  }, [program?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const info = shown ?
  [
  { label: 'Penanggung Jawab', value: shown.pic },
  { label: 'Bidang/Seksi', value: shown.division },
  { label: 'Periode Pelaksanaan', value: shown.period },
  { label: 'Tahun', value: shown.year },
  { label: 'Sasaran', value: shown.target }] :

  [];

  return (
    <Modal
      open={program !== null}
      onClose={onClose}
      title={shown?.name ?? 'Detail Program'}
      hideTitle
      size="xl"
      footer={
      shown &&
      <div className="flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-ink-faint">{isEditing ? 'Anda sedang dalam Edit Mode.' : 'Hanya pengurus berwenang yang dapat mengubah program.'}</p>
            <div className="flex gap-3">
              <button type="button" onClick={onClose} className={btnSecondary}>
                Tutup
              </button>
              <button type="button" onClick={() => isEditing ? onEdit(shown) : requestEditMode()} className={btnPrimary}>
                {isEditing ? <PencilIcon className="h-4 w-4" aria-hidden="true" /> : <LockIcon className="h-4 w-4" aria-hidden="true" />}
                Edit Program
              </button>
            </div>
          </div>

      }>
      
      {shown &&
      <div>
          <div className="border-b border-line bg-cream px-6 pb-0 pt-7 sm:px-8">
            <div className="flex flex-wrap items-center gap-3 pr-12">
              <StatusBadge status={shown.status} />
              <span className="text-sm text-ink-faint">{shown.division || '[Seksi/Bidang]'}</span>
            </div>
            <h2 className={`mt-3 font-heading text-2xl font-semibold text-navy sm:text-3xl ${placeholderClass(shown.name)}`}>{shown.name}</h2>
            <div className="mt-4 max-w-md">
              <div className="flex justify-between text-sm">
                <span className="text-ink-soft">Progress</span>
                <span className="font-semibold text-navy">{shown.progress}%</span>
              </div>
              <div className="mt-1.5 h-2 rounded-full bg-white ring-1 ring-line">
                <div className="h-full rounded-full bg-sage-600 transition-[width] duration-300 ease-out" style={{ width: `${shown.progress}%` }} />
              </div>
            </div>
            <div role="tablist" aria-label="Bagian detail program" className="scrollbar-none -mx-2 mt-6 flex overflow-x-auto">
              {tabs.map((t) =>
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className={`whitespace-nowrap border-b-[3px] px-3 py-3 text-sm font-semibold transition-colors duration-150 ${
              tab === t.id ? 'border-navy text-navy' : 'border-transparent text-ink-faint hover:text-navy'}`
              }>
              
                  {t.label}
                </button>
            )}
            </div>
          </div>

          <div className="p-6 sm:p-8" role="tabpanel">
            {tab === 'ringkasan' &&
          <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
                <div className="space-y-7">
                  <TextBlock title="Deskripsi Singkat" value={shown.summary} />
                  <section>
                    <h4 className="font-heading text-[15px] font-semibold text-navy">SDGs Terkait</h4>
                    <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                      {shown.sdgs.map((n) => {
                    const sdg = getSdg(n);
                    return (
                      <li key={n} className="flex items-center gap-3 rounded-xl border border-line p-2.5">
                            <SdgTile sdg={sdg} size="sm" />
                            <span className="text-sm font-medium leading-snug text-ink">{sdg.name}</span>
                          </li>);

                  })}
                      {shown.sdgs.length === 0 && <li className="italic text-ink-faint">[Belum dipetakan]</li>}
                    </ul>
                  </section>
                </div>
                <dl className="divide-y divide-line rounded-2xl border border-line">
                  {info.map((row) =>
              <div key={row.label} className="px-5 py-3.5">
                      <dt className="text-[13px] text-ink-faint">{row.label}</dt>
                      <dd className={`mt-0.5 font-medium text-ink ${placeholderClass(row.value || '[')}`}>{row.value || '[Belum diisi]'}</dd>
                    </div>
              )}
                </dl>
              </div>
          }

            {tab === 'perencanaan' &&
          <div className="grid gap-7 md:grid-cols-2">
                <TextBlock title="Latar Belakang" value={shown.background} />
                <TextBlock title="Tujuan" value={shown.goal} />
                <TextBlock title="Sasaran" value={shown.target} />
                <ListBlock title="Indikator Keberhasilan" items={shown.indicators} />
              </div>
          }

            {tab === 'pelaksanaan' &&
          <div className="grid gap-7 md:grid-cols-2">
                <TextBlock title="Penanggung Jawab" value={shown.pic} />
                <TextBlock title="Periode Pelaksanaan" value={shown.period} />
                <section className="md:col-span-2">
                  <h4 className="font-heading text-[15px] font-semibold text-navy">Status</h4>
                  <div className="mt-2">
                    <StatusBadge status={shown.status} />
                  </div>
                </section>
                <div className="md:col-span-2">
                  <ListBlock title="Dokumentasi" items={shown.documentation} icon />
                </div>
              </div>
          }

            {tab === 'refleksi' &&
          <div className="grid gap-7 md:grid-cols-2">
                <TextBlock title="Evaluasi" value={shown.evaluation} />
                <TextBlock title="Hambatan" value={shown.obstacles} />
                <TextBlock title="Solusi" value={shown.solutions} />
                <TextBlock title="Rencana Pengembangan" value={shown.development} />
                <div className="md:col-span-2">
                  <TextBlock title="Lessons Learned — untuk pengurus berikutnya" value={shown.lessons} emphasis />
                </div>
              </div>
          }
          </div>
        </div>
      }
    </Modal>);

}