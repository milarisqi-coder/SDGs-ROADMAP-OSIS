import React from 'react';
import { ArrowRightIcon, PencilIcon } from 'lucide-react';
import { StatusBadge } from '../ui/StatusBadge';
import { ConfirmButton } from '../ui/ConfirmButton';
import { SdgChip } from '../sdg/SdgChip';
import type { Program } from '../../types/program';
import { iconBtn } from '../../utils/styles';
import { placeholderClass } from '../../utils/text';

interface ProgramCardProps {
  program: Program;
  editing: boolean;
  onOpen: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export function ProgramCard({ program, editing, onOpen, onEdit, onDelete }: ProgramCardProps) {
  return (
    <article className="group relative flex h-full flex-col rounded-3xl border border-line bg-white p-6 shadow-soft transition-[transform,box-shadow] duration-200 ease-out hover:-translate-y-1 hover:shadow-lift">
      <div className="flex items-center justify-between gap-3">
        <StatusBadge status={program.status} />
        <span className="text-sm font-medium text-ink-faint">{program.year}</span>
      </div>

      <h3 className="mt-4 font-heading text-lg font-semibold text-navy">
        <button type="button" onClick={onOpen} className="text-left after:absolute after:inset-0 after:rounded-3xl focus-visible:outline-none">
          <span className={placeholderClass(program.name)}>{program.name}</span>
        </button>
      </h3>
      <p className="mt-1 text-sm font-medium text-sage-700">{program.division || '[Seksi/Bidang]'}</p>
      <p className={`mt-3 line-clamp-3 text-[15px] leading-relaxed text-ink-soft ${placeholderClass(program.summary || '[')}`}>
        {program.summary || '[Deskripsi singkat belum diisi.]'}
      </p>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {program.sdgs.length ? program.sdgs.map((n) => <SdgChip key={n} number={n} />) : <span className="text-xs text-ink-faint">SDGs belum dipetakan</span>}
      </div>

      <div className="mt-auto pt-5">
        <div className="flex justify-between text-xs text-ink-faint">
          <span>Progress</span>
          <span className="font-semibold text-ink-soft">{program.progress}%</span>
        </div>
        <div className="mt-1.5 h-1.5 rounded-full bg-navy-50" role="progressbar" aria-valuenow={program.progress} aria-valuemin={0} aria-valuemax={100} aria-label={`Progress ${program.name}`}>
          <div className="h-full rounded-full bg-sage-600" style={{ width: `${program.progress}%` }} />
        </div>
        <div className="mt-4 flex items-center justify-between">
          <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-navy">
            Lihat Detail
            <ArrowRightIcon className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5" aria-hidden="true" />
          </span>
          {editing &&
          <div className="relative z-10 flex items-center">
              <button type="button" onClick={onEdit} className={iconBtn} aria-label={`Edit ${program.name}`}>
                <PencilIcon className="h-4 w-4" />
              </button>
              <ConfirmButton label={program.name} onConfirm={onDelete} />
            </div>
          }
        </div>
      </div>
    </article>);

}