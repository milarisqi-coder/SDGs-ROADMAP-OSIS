import React from 'react';
import { SproutIcon } from 'lucide-react';

export function LogoMark({ inverted = false }: {inverted?: boolean;}) {
  return (
    <span
      className={`relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
      inverted ? 'bg-white text-navy' : 'bg-navy text-sunny'}`
      }
      role="img"
      aria-label="Logo OSIS (placeholder)">
      
      <SproutIcon className="h-5 w-5" aria-hidden="true" />
      <span className="absolute -bottom-1 -right-1 h-3.5 w-3.5 rounded-full border-2 border-cream bg-sage" aria-hidden="true" />
    </span>);

}