import React from 'react';
import { SchoolIcon } from 'lucide-react';
import { LogoMark } from './LogoMark';
import { navTabs } from '../../data/navigation';
import { useNavigation } from '../../contexts/NavigationContext';
import { container } from '../../utils/styles';

export function Footer() {
  const { goTo } = useNavigation();
  return (
    <footer className="bg-navy text-white">
      <div className={`${container} grid gap-12 py-16 lg:grid-cols-[1.2fr_1.4fr_1fr]`}>
        <div>
          <div className="flex items-center gap-3">
            <LogoMark inverted />
            <span className="font-heading text-lg font-bold tracking-wide">SDGs ROADMAP OSIS</span>
          </div>
          <p className="mt-5 max-w-sm font-heading text-xl font-medium leading-snug text-navy-100">
            From Student Activities to Sustainable Impact.
          </p>
        </div>

        <nav aria-label="Navigasi footer">
          <p className="text-sm font-semibold text-sunny">Navigasi</p>
          <ul className="mt-4 grid grid-cols-1 gap-x-8 gap-y-2.5 sm:grid-cols-2">
            {navTabs.map((tab) =>
            <li key={tab.id}>
                <button
                type="button"
                onClick={() => goTo(tab.id)}
                className="text-[15px] text-navy-100 transition-colors duration-150 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sunny">
                
                  {tab.label}
                </button>
              </li>
            )}
          </ul>
        </nav>

        <div>
          <p className="text-sm font-semibold text-sunny">Sekolah</p>
          <p className="mt-4 flex items-center gap-2 text-[15px] text-white">
            <SchoolIcon className="h-4 w-4 text-navy-100" aria-hidden="true" />
            SMP Negeri 37 Surabaya
          </p>
          <p className="mt-8 font-heading text-2xl font-semibold text-white">“One Student, Once Impact.”</p>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className={`${container} flex flex-col gap-2 py-6 text-sm text-navy-100 sm:flex-row sm:justify-between`}>
          <p>© 2026 SDGs Roadmap OSIS</p>
          <p>Know the SDGs. Map the Programs. Create the Impact. Continue the Change.</p>
        </div>
      </div>
    </footer>);

}