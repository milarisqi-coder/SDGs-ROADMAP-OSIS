import React from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Toaster } from 'sonner';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { EditAccessModal } from './EditAccessModal';
import { useNavigation } from '../../contexts/NavigationContext';
import type { TabId } from '../../types/content';
import { Home } from '../../pages/Home';
import { WhyPage } from '../../pages/WhyPage';
import { SdgsPage } from '../../pages/SdgsPage';
import { PriorityPage } from '../../pages/PriorityPage';
import { StudentsPage } from '../../pages/StudentsPage';
import { StructurePage } from '../../pages/StructurePage';
import { ProgramsPage } from '../../pages/ProgramsPage';
import { RoadmapPage } from '../../pages/RoadmapPage';
import { HandbookPage } from '../../pages/HandbookPage';

const pages: Record<TabId, React.ComponentType> = {
  beranda: Home,
  mengapa: WhyPage,
  sdgs: SdgsPage,
  prioritas: PriorityPage,
  pelajar: StudentsPage,
  struktur: StructurePage,
  program: ProgramsPage,
  roadmap: RoadmapPage,
  handbook: HandbookPage
};

export function SiteShell() {
  const { activeTab } = useNavigation();
  const reduce = useReducedMotion();
  const Page = pages[activeTab];

  return (
    <div className="flex min-h-screen w-full flex-col bg-cream font-sans text-ink">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-navy focus:px-4 focus:py-2 focus:text-white">
        
        Lewati ke konten
      </a>
      <Navbar />
      <main id="main" className="flex-1 overflow-x-clip">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={activeTab}
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}>
            
            <Page />
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer />
      <EditAccessModal />
      <Toaster position="bottom-center" toastOptions={{ style: { fontFamily: 'Inter, sans-serif', borderRadius: '16px' } }} />
    </div>);

}