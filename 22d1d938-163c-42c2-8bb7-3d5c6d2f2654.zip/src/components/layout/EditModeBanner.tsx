import React from 'react';
import { useEditMode } from '../../contexts/EditModeContext';
import { container } from '../../utils/styles';
import { formatDateTime } from '../../utils/text';

export function EditModeBanner() {
  const { meta } = useEditMode();
  return (
    <div className="border-t border-sage-200 bg-sage-100" role="status">
      <div className={`${container} flex flex-wrap items-center gap-x-6 gap-y-1 py-2 text-sm`}>
        <span className="inline-flex items-center gap-2 font-semibold tracking-wide text-sage-700">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full rounded-full bg-sage-600 opacity-60 motion-safe:animate-ping" />
            <span className="relative h-2 w-2 rounded-full bg-sage-700" />
          </span>
          EDIT MODE ACTIVE
        </span>
        <span className="text-ink-soft">
          Last Updated: <span className="font-semibold text-ink">{formatDateTime(meta.lastUpdated)}</span>
        </span>
        <span className="text-ink-soft">
          Updated By: <span className="font-semibold text-ink">{meta.updatedBy}</span>
        </span>
        <span className="hidden text-ink-faint xl:inline">Struktur OSIS, Program Kerja, dan Handbook dapat diperbarui.</span>
      </div>
    </div>);

}