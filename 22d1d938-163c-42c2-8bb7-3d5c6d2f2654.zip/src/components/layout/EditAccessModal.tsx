import React, { useEffect, useState } from 'react';
import { CheckIcon, LockIcon } from 'lucide-react';
import { toast } from 'sonner';
import { Modal } from '../ui/Modal';
import { FormField } from '../ui/FormField';
import { useEditMode } from '../../contexts/EditModeContext';
import { btnPrimary, btnSecondary, inputClass } from '../../utils/styles';

const editableAreas = ['Struktur OSIS: pengurus, jabatan, seksi, periode', 'Program Kerja: deskripsi, SDGs, status, progress, evaluasi', 'Handbook: isi bab dan sumber tambahan'];

export function EditAccessModal() {
  const { accessOpen, closeAccess, enableEditMode } = useEditMode();
  const [name, setName] = useState('');

  useEffect(() => {
    if (accessOpen) setName('');
  }, [accessOpen]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) return;
    enableEditMode(trimmed);
    toast.success('Edit Mode aktif. Perubahan akan tercatat atas nama Anda.');
  };

  return (
    <Modal open={accessOpen} onClose={closeAccess} title="Masuk Edit Mode" size="md">
      <form onSubmit={submit} className="space-y-6 p-6">
        <div className="flex gap-3 rounded-2xl bg-beige-50 p-4">
          <LockIcon className="mt-0.5 h-5 w-5 shrink-0 text-beige-700" aria-hidden="true" />
          <p className="text-sm leading-relaxed text-ink-soft">
            Pengunjung umum hanya dapat melihat website. Edit Mode digunakan oleh pengurus OSIS atau pembina yang berwenang untuk
            memperbarui data demi keberlanjutan antarperiode.
          </p>
        </div>
        <div>
          <p className="text-sm font-semibold text-ink">Yang dapat diperbarui</p>
          <ul className="mt-2 space-y-1.5">
            {editableAreas.map((area) =>
            <li key={area} className="flex items-start gap-2 text-sm text-ink-soft">
                <CheckIcon className="mt-0.5 h-4 w-4 shrink-0 text-sage-700" aria-hidden="true" />
                {area}
              </li>
            )}
          </ul>
        </div>
        <FormField label="Nama Editor" htmlFor="editor-name" hint="Dicatat sebagai 'Updated By' pada setiap perubahan.">
          <input
            id="editor-name"
            className={inputClass}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Contoh: Sekretaris OSIS 2026"
            required />
          
        </FormField>
        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button type="button" onClick={closeAccess} className={btnSecondary}>
            Cancel
          </button>
          <button type="submit" className={btnPrimary} disabled={!name.trim()}>
            Aktifkan Edit Mode
          </button>
        </div>
      </form>
    </Modal>);

}