import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { MenuIcon, PencilIcon, XIcon } from 'lucide-react';
import { toast } from 'sonner';
import { LogoMark } from './LogoMark';
import { EditModeBanner } from './EditModeBanner';
import { navTabs } from '../../data/navigation';
import { useNavigation } from '../../contexts/NavigationContext';
import { useEditMode } from '../../contexts/EditModeContext';
import type { TabId } from '../../types/content';
import { container, iconBtn } from '../../utils/styles';

export function Navbar() {
  const { activeTab, goTo } = useNavigation();
  const { isEditing, requestEditMode, disableEditMode } = useEditMode();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleNav = (id: TabId) => {
    goTo(id);
    setMenuOpen(false);
  };

  const handleEdit = () => {
    if (isEditing) {
      disableEditMode();
      toast.success('Edit Mode dinonaktifkan. Semua perubahan tersimpan.');
    } else {
      requestEditMode();
    }
  };

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-cream/95 backdrop-blur-sm">
      <div className={`${container} flex h-16 items-center justify-between gap-4`}>
        <button
          type="button"
          onClick={() => handleNav('beranda')}
          className="flex items-center gap-3 rounded-xl text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy"
          aria-label="SDGs Roadmap OSIS — ke Beranda">
          
          <LogoMark />
          <span>
            <span className="block whitespace-nowrap font-heading text-[15px] font-bold tracking-wide text-navy">SDGs ROADMAP OSIS</span>
            <span className="block whitespace-nowrap text-xs text-ink-faint">SMP Negeri 37 Surabaya</span>
          </span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleEdit}
            aria-pressed={isEditing}
            className={`inline-flex items-center gap-2 whitespace-nowrap rounded-full px-3.5 py-2 text-sm font-semibold transition-[background-color,color,border-color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-navy ${
            isEditing ?
            'border border-sage-600 bg-sage-700 text-white hover:bg-sage-600' :
            'border border-navy/15 bg-white text-navy hover:bg-navy-50'}`
            }>
            
            {isEditing ?
            <span className="h-2 w-2 rounded-full bg-sunny" aria-hidden="true" /> :

            <PencilIcon className="h-3.5 w-3.5" aria-hidden="true" />
            }
            <span>{isEditing ? 'Selesai Edit' : 'Edit Mode'}</span>
          </button>
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            className={`${iconBtn} h-10 w-10 lg:hidden`}
            aria-expanded={menuOpen}
            aria-controls="mobile-nav"
            aria-label={menuOpen ? 'Tutup menu' : 'Buka menu'}>
            
            {menuOpen ? <XIcon className="h-5 w-5" /> : <MenuIcon className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <nav aria-label="Navigasi utama" className="hidden border-t border-line/70 lg:block">
        <div className={container}>
          <ul className="scrollbar-none -mx-3 flex items-center overflow-x-auto">
            {navTabs.map((tab) => {
              const active = tab.id === activeTab;
              return (
                <li key={tab.id} className="shrink-0">
                  <button
                    type="button"
                    onClick={() => handleNav(tab.id)}
                    aria-current={active ? 'page' : undefined}
                    className={`relative whitespace-nowrap px-3 py-3 text-[14px] font-medium transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-navy ${
                    active ? 'text-navy' : 'text-ink-soft hover:text-navy'}`
                    }>
                    
                    {tab.label}
                    {active &&
                    <motion.span
                      layoutId="nav-underline"
                      className="absolute inset-x-3 bottom-0 h-[3px] rounded-full bg-navy"
                      transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }} />

                    }
                  </button>
                </li>);

            })}
          </ul>
        </div>
      </nav>

      <AnimatePresence initial={false}>
        {menuOpen &&
        <motion.nav
          id="mobile-nav"
          aria-label="Navigasi utama"
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
          className="overflow-hidden border-t border-line bg-cream lg:hidden">
          
            <ul className={`${container} grid gap-1 py-3 sm:grid-cols-2`}>
              {navTabs.map((tab, i) => {
              const active = tab.id === activeTab;
              return (
                <li key={tab.id}>
                    <button
                    type="button"
                    onClick={() => handleNav(tab.id)}
                    aria-current={active ? 'page' : undefined}
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-[15px] font-medium transition-colors duration-150 ${
                    active ? 'bg-navy text-white' : 'text-ink hover:bg-white'}`
                    }>
                    
                      <span className={`w-5 text-xs font-semibold ${active ? 'text-navy-100' : 'text-ink-faint'}`}>{i + 1}</span>
                      {tab.label}
                    </button>
                  </li>);

            })}
            </ul>
          </motion.nav>
        }
      </AnimatePresence>

      {isEditing && <EditModeBanner />}
    </header>);

}