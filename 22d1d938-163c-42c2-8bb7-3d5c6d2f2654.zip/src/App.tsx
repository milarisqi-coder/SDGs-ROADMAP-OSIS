import React from 'react';
import { EditModeProvider } from './contexts/EditModeContext';
import { SchoolDataProvider } from './contexts/SchoolDataContext';
import { NavigationProvider } from './contexts/NavigationContext';
import { SiteShell } from './components/layout/SiteShell';

export function App() {
  return (
    <EditModeProvider>
      <SchoolDataProvider>
        <NavigationProvider>
          <SiteShell />
        </NavigationProvider>
      </SchoolDataProvider>
    </EditModeProvider>);

}